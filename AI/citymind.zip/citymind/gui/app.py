"""
gui/app.py — CityGuard Graphical User Interface

Matches the wireframe:
  • Dark topbar — CITYGUARD SIMULATION wordmark, step progress, units dot
  • Left sidebar — resizable via drag sash; TEXT SIZE slider at top
  • Isometric 10×10 city grid (diamond cells, perspective projection)
  • Bottom log panel — step number + message rows
  • Node detail popup on cell click
"""

import tkinter as tk
import tkinter.font as tkfont
from tkinter import ttk
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from city_graph import COLORS, TYPES, RISK_COLORS, AMB_ZONE_COLORS
from simulation import CitySimulation
from algorithms.genetic_ambulance import compute_coverage_zones

# ── Design tokens (wireframe palette) ──────────────────────────────────
BG         = '#faf8f4'
BG_MID     = '#f2efe9'
BG_DARK    = '#1c1a17'
BORDER     = '#dedad3'
BORDER_STR = '#c8c2b8'
TEXT       = '#1c1a17'
TEXT_MID   = '#5a5650'
TEXT_SOFT  = '#9b9690'
ACCENT     = '#e05555'
GREEN      = '#3dba6e'
AMBER      = '#c49a1a'
BLUE       = '#3b78c4'

CELL_BORDERS = {
    'R': '#3b78c4', 'H': '#e05555', 'S': '#2d9e55',
    'I': '#c49a1a', 'P': '#7c3aed', 'A': '#ea7c09', 'E': '#9e9a92',
}

# ── Detect screen size and derive layout constants ──────────────────────
_tmp = tk.Tk()
_tmp.withdraw()
_SW = _tmp.winfo_screenwidth()
_SH = _tmp.winfo_screenheight()
_tmp.destroy()
del _tmp

WIN_W  = _SW - 20
WIN_H  = _SH - 60
TOP_H  = max(50,  _SH // 30)
LOG_H  = max(150, _SH // 9)
SB_W   = max(280, _SW // 8)        # initial sidebar width (user can drag sash)
BODY_H = WIN_H - TOP_H - LOG_H
GRID_W = WIN_W - SB_W

# ── Isometric grid constants ────────────────────────────────────────────
N         = 10
_CANVAS_H = BODY_H - 26
_TW_w = int(GRID_W   * 0.82 / 9.5)
_TW_h = int(_CANVAS_H * 0.80 / 5)
TW    = ((min(_TW_w, _TW_h)) // 2) * 2
TH    = TW // 2

# Canvas origin — updated dynamically when canvas is resized
_OX = (GRID_W  - (9 * TW + TW // 2)) // 2 + 9 * TW // 2
_OY = (_CANVAS_H - 10 * TH) // 2

# ── Font size defaults ──────────────────────────────────────────────────
_fs     = max(1.0, min(1.25, _SH / 1080))
FS_XS   = int(9  * _fs)
FS_SM   = int(11 * _fs)
FS_MD   = int(13 * _fs)
FS_WM   = int(15 * _fs)
FS_CELL = max(10, min(16, TW // 14))

# Font objects — populated by CityMindApp.__init__ after Tk root exists
_F: dict = {}


# ── Isometric geometry helpers ──────────────────────────────────────────

def _iso_top(r, c):
    return (_OX + (c - r) * TW // 2,
            _OY + (c + r) * TH // 2)


def _iso_polygon(r, c):
    tx, ty = _iso_top(r, c)
    return [tx, ty,  tx+TW//2, ty+TH//2,  tx, ty+TH,  tx-TW//2, ty+TH//2]


def _iso_center(r, c):
    tx, ty = _iso_top(r, c)
    return tx, ty + TH // 2


def _screen_to_cell(px, py):
    cr  = 2 * (px - _OX) / TW
    cpr = 2 * (py - _OY - TH / 2) / TH
    c = round((cr + cpr) / 2)
    r = round((cpr - cr) / 2)
    if 0 <= r < N and 0 <= c < N:
        return r, c
    return -1, -1


def _darken(hex_color):
    try:
        r = max(0, int(hex_color[1:3], 16) - 60)
        g = max(0, int(hex_color[3:5], 16) - 60)
        b = max(0, int(hex_color[5:7], 16) - 60)
        return f'#{r:02x}{g:02x}{b:02x}'
    except Exception:
        return '#333333'


# ── Application ─────────────────────────────────────────────────────────

class CityMindApp(tk.Tk):

    def __init__(self):
        super().__init__()
        self.title("CityGuard — Urban Intelligence System")
        self.configure(bg=BG_DARK)
        self.resizable(True, True)
        self.geometry(f"{WIN_W}x{WIN_H}")

        # ── Font objects (live — configure() on any Font updates all widgets using it)
        global _F
        _F['xs']      = tkfont.Font(family='Courier',   size=FS_XS)
        _F['sm']      = tkfont.Font(family='Courier',   size=FS_SM)
        _F['md']      = tkfont.Font(family='Helvetica', size=FS_MD)
        _F['mdb']     = tkfont.Font(family='Helvetica', size=FS_MD,   weight='bold')
        _F['smb']     = tkfont.Font(family='Helvetica', size=FS_SM,   weight='bold')
        _F['xsb']     = tkfont.Font(family='Helvetica', size=FS_XS,   weight='bold')
        _F['wm']      = tkfont.Font(family='Helvetica', size=FS_WM,   weight='bold')
        _F['cell']    = tkfont.Font(family='Helvetica', size=FS_CELL, weight='bold')
        _F['cellbig'] = tkfont.Font(family='Helvetica', size=FS_CELL + 2, weight='bold')

        # Style the PanedWindow sash
        style = ttk.Style(self)
        style.theme_use('clam')
        style.configure('TPanedwindow', background=BORDER)
        style.configure('Sash', sashpad=3, sashrelief='flat',
                        background=BORDER_STR)

        self.sim = CitySimulation(rows=N, cols=N)

        self.ov_roads = tk.BooleanVar(value=False)
        self.ov_amb   = tk.BooleanVar(value=False)
        self.ov_heat  = tk.BooleanVar(value=False)

        self._auto_id    = None
        self._log_count  = 0
        self._flood_mode = False
        self._risk_mult  = False
        self._selected   = None

        # Build order: topbar → log (bottom) → body (fills middle)
        self._build_topbar()
        self._build_log()
        self._build_body()

        self.sim.city.subscribe(self._refresh_canvas)
        self.after(60, self._refresh_canvas)

    # ── Font size slider callback ────────────────────────────────────────

    def _on_font_size(self, _=None):
        base = int(self._font_scale.get())
        _F['xs'].configure(size=max(7,  base - 4))
        _F['sm'].configure(size=max(8,  base - 2))
        _F['md'].configure(size=base)
        _F['mdb'].configure(size=base)
        _F['smb'].configure(size=max(8, base - 2))
        _F['xsb'].configure(size=max(7, base - 4))
        _F['wm'].configure(size=base + 2)
        _F['cell'].configure(size=max(8,  min(18, base)))
        _F['cellbig'].configure(size=max(9, min(20, base + 2)))
        self._refresh_canvas()

    # ── Layout builders ──────────────────────────────────────────────────

    def _build_topbar(self):
        bar = tk.Frame(self, bg=BG_DARK, height=TOP_H)
        bar.pack(fill='x', side='top')
        bar.pack_propagate(False)

        _L = TOP_H - 14
        logo = tk.Canvas(bar, bg=BG_DARK, width=_L*2+2, height=_L*2+2,
                          highlightthickness=0)
        logo.place(x=12, y=(TOP_H - _L*2) // 2)
        for lr, lc in [(0, 0), (0, 1), (1, 0)]:
            logo.create_rectangle(lc*(_L+1)+1, lr*(_L+1)+1,
                                   lc*(_L+1)+_L, lr*(_L+1)+_L,
                                   outline='#faf8f4', width=1.5, fill='')
        logo.create_rectangle(_L+2, _L+2, _L*2+1, _L*2+1, fill=ACCENT, outline=ACCENT)
        mx, my = _L*1.5+1, _L*1.5+1
        logo.create_line(mx, my-_L*0.3, mx, my+_L*0.3, fill='white', width=1.8)
        logo.create_line(mx-_L*0.3, my, mx+_L*0.3, my, fill='white', width=1.8)

        _wm_x = 18 + _L*2 + 8
        tk.Label(bar, text='CITYGUARD', bg=BG_DARK, fg=BG,
                 font=_F['wm']).place(x=_wm_x, y=7)
        tk.Label(bar, text='SIMULATION', bg=BG_DARK, fg='#9ca3af',
                 font=_F['sm']).place(x=_wm_x, y=TOP_H - FS_SM - 6)

        _pw = max(100, int(WIN_W * 0.085))
        tk.Label(bar, text='STEP', bg=BG_DARK, fg='#9ca3af',
                 font=_F['sm']).place(relx=1.0, x=-(_pw + 110), y=TOP_H//2 - FS_SM//2)

        self._prog_w = _pw
        self._prog_bg = tk.Canvas(bar, bg='#333333', width=_pw, height=4,
                                   highlightthickness=0)
        self._prog_bg.place(relx=1.0, x=-(_pw + 60), y=TOP_H//2)
        self._prog_fill = self._prog_bg.create_rectangle(0, 0, 0, 4,
                                                          fill='#6b7280', outline='')

        self._step_lbl = tk.Label(bar, text='00 / 20', bg=BG_DARK, fg='#9ca3af',
                                   font=_F['sm'])
        self._step_lbl.place(relx=1.0, x=-58, y=TOP_H//2 - FS_SM//2)

        tk.Canvas(bar, bg='#2e2c28', width=1, height=22,
                  highlightthickness=0).place(relx=1.0, x=-30, y=TOP_H//2 - 11)

        self._dot = tk.Canvas(bar, bg=BG_DARK, width=10, height=10,
                               highlightthickness=0)
        self._dot.place(relx=1.0, x=-22, y=TOP_H//2 - 5)
        self._dot_oval = self._dot.create_oval(1, 1, 9, 9, fill='#6b7280', outline='')

        self._units_lbl = tk.Label(bar, text='0 UNITS', bg=BG_DARK, fg='#9ca3af',
                                    font=_F['xs'])
        self._units_lbl.place(relx=1.0, x=-6, y=TOP_H//2 - FS_XS//2)

    def _build_body(self):
        """Horizontal PanedWindow — drag the sash to resize sidebar freely."""
        paned = ttk.PanedWindow(self, orient='horizontal')
        paned.pack(fill='both', expand=True)
        self._paned = paned

        sb_frame = tk.Frame(paned, bg=BG_MID,
                             highlightbackground=BORDER, highlightthickness=1)
        grid_frame = tk.Frame(paned, bg=BG)

        paned.add(sb_frame,   weight=0)
        paned.add(grid_frame, weight=1)

        self._build_sidebar(sb_frame)
        self._build_canvas_area(grid_frame)

        # Set initial sash position after geometry is settled
        self.after(30, lambda: paned.sashpos(0, SB_W))

    def _build_sidebar(self, sb):
        PX = 16

        # ── Text size slider ──────────────────────────────────────────
        size_row = tk.Frame(sb, bg=BG_MID)
        size_row.pack(fill='x', padx=PX, pady=(10, 4))
        tk.Label(size_row, text='TEXT SIZE', bg=BG_MID, fg=TEXT_SOFT,
                 font=_F['xs']).pack(side='left')
        self._font_scale = tk.Scale(
            size_row, from_=8, to=22, resolution=1,
            orient='horizontal', bg=BG_MID, fg=TEXT_MID,
            highlightthickness=0, troughcolor=BORDER,
            sliderrelief='flat', sliderlength=14, width=7,
            showvalue=True, font=('Helvetica', 7),
            command=self._on_font_size)
        self._font_scale.set(FS_MD)
        self._font_scale.pack(side='left', padx=(6, 0), fill='x', expand=True)

        tk.Frame(sb, bg=BORDER, height=1).pack(fill='x', padx=8, pady=(4, 0))

        # ── OVERLAYS ──────────────────────────────────────────────────
        _sec(sb, 'Overlays')
        _chk(sb, 'Road Network',       self.ov_roads, self._refresh_canvas, PX)
        _chk(sb, 'Ambulance Coverage', self.ov_amb,   self._refresh_canvas, PX)
        _chk(sb, 'Crime Risk Heatmap', self.ov_heat,  self._refresh_canvas, PX)
        _gap(sb, 10)

        # ── SIMULATION ────────────────────────────────────────────────
        _sec(sb, 'Simulation')

        row1 = tk.Frame(sb, bg=BG_MID)
        row1.pack(fill='x', padx=PX, pady=(0, 5))
        self._run_btn = _btn(row1, 'RUN',   self._on_run,   dark=True)
        self._run_btn.pack(side='left', padx=(0, 5))
        _btn(row1, 'PAUSE', self._on_pause).pack(side='left')

        row2 = tk.Frame(sb, bg=BG_MID)
        row2.pack(fill='x', padx=PX, pady=(0, 5))
        _btn(row2, 'STEP', self._on_step).pack(side='left', padx=(0, 5))
        _btn(row2, 'INIT', self._on_initialize, dark=True).pack(side='left')

        spd = tk.Frame(sb, bg=BG_MID)
        spd.pack(fill='x', padx=PX, pady=(0, 2))
        tk.Label(spd, text='SPEED', bg=BG_MID, fg=TEXT_SOFT,
                 font=_F['sm']).pack(side='left')
        self._speed = tk.Scale(spd, from_=0.25, to=2.0, resolution=0.25,
                               orient='horizontal', bg=BG_MID, fg=TEXT_MID,
                               highlightthickness=0, troughcolor=BORDER,
                               sliderrelief='flat', sliderlength=14,
                               width=8, length=100, showvalue=False)
        self._speed.set(1.0)
        self._speed.pack(side='left', padx=(4, 2), fill='x', expand=True)
        self._spd_lbl = tk.Label(spd, text='×1', bg=BG_MID, fg=TEXT_SOFT,
                                  font=_F['sm'])
        self._spd_lbl.pack(side='left')
        self._speed.configure(command=self._on_speed_change)
        _gap(sb, 10)

        # ── OVERRIDE ──────────────────────────────────────────────────
        _sec(sb, 'Override')

        self._flood_btn = tk.Button(
            sb, text='Flood Road', command=self._on_flood,
            bg='#f8faff', fg='#93afd4', activebackground='#dbeafe',
            activeforeground='#1e40af', relief='flat',
            font=_F['md'], pady=5, padx=10, anchor='w',
            highlightbackground='#bfdbfe', highlightthickness=1, cursor='hand2')
        self._flood_btn.pack(fill='x', padx=PX, pady=(0, 5))

        self._risk_btn = tk.Button(
            sb, text='Risk Mult ×2', command=self._on_risk,
            bg='#fffdf7', fg='#c4a458', activebackground='#fef3c7',
            activeforeground='#78350f', relief='flat',
            font=_F['md'], pady=5, padx=10, anchor='w',
            highlightbackground='#fde68a', highlightthickness=1, cursor='hand2')
        self._risk_btn.pack(fill='x', padx=PX, pady=(0, 5))
        _gap(sb, 10)

        # ── LEGEND ────────────────────────────────────────────────────
        _sec(sb, 'Legend')
        for code, label in [
            ('H', 'Hospital'), ('R', 'Residential'), ('I', 'Industrial'),
            ('S', 'School'),   ('P', 'Power Plant'), ('A', 'Amb. Depot'),
            ('E', 'Empty'),
        ]:
            row = tk.Frame(sb, bg=BG_MID)
            row.pack(fill='x', padx=PX, pady=2)
            sw = tk.Canvas(row, width=14, height=14, bg=BG_MID,
                            highlightthickness=0)
            sw.pack(side='left', padx=(0, 8))
            sw.create_rectangle(1, 1, 13, 13,
                                 fill=COLORS.get(code, '#ccc'),
                                 outline=CELL_BORDERS.get(code, BORDER),
                                 width=1.5)
            tk.Label(row, text=label, bg=BG_MID, fg=TEXT_MID,
                     font=_F['md']).pack(side='left')

        tk.Button(sb, text='Reset', bg=BG_MID, fg=TEXT_SOFT, relief='flat',
                  font=('Helvetica', 8), command=self._on_reset,
                  cursor='hand2').pack(side='bottom', pady=6)

    def _build_canvas_area(self, parent):
        frame = tk.Frame(parent, bg=BG)
        frame.pack(fill='both', expand=True)

        lbl_bar = tk.Frame(frame, bg=BG, height=20)
        lbl_bar.pack(fill='x')
        lbl_bar.pack_propagate(False)

        self._grid_lbl = tk.Label(lbl_bar, text='GRID VIEW — DEFAULT',
                                   bg=BG, fg=TEXT_SOFT, font=('Courier', 8),
                                   anchor='w')
        self._grid_lbl.pack(side='left', padx=10, pady=4)
        tk.Frame(lbl_bar, bg=BORDER, height=1).pack(
            side='left', fill='x', expand=True, pady=9)
        tk.Label(lbl_bar, text='10×10', bg=BG, fg=TEXT_SOFT,
                 font=('Courier', 8)).pack(side='right', padx=10, pady=4)

        self.canvas = tk.Canvas(frame, bg=BG, highlightthickness=0)
        self.canvas.pack(fill='both', expand=True)
        self.canvas.bind('<Button-1>', self._on_click)
        self.canvas.bind('<Configure>', self._on_canvas_resize)

    def _on_canvas_resize(self, event):
        """Keep the isometric grid centred as canvas area changes."""
        global _OX, _OY
        _OX = (event.width  - (9 * TW + TW // 2)) // 2 + 9 * TW // 2
        _OY = (event.height - 10 * TH) // 2
        self._refresh_canvas()

    def _build_log(self):
        log = tk.Frame(self, bg=BG_MID, height=LOG_H,
                        highlightbackground=BORDER, highlightthickness=1)
        log.pack(fill='x', side='bottom')
        log.pack_propagate(False)

        hdr = tk.Frame(log, bg=BG_MID)
        hdr.pack(fill='x', padx=14, pady=(7, 3))
        tk.Label(hdr, text='Event Log', bg=BG_MID, fg=TEXT_MID,
                 font=_F['mdb']).pack(side='left')

        self._live_dot = tk.Canvas(hdr, bg=BG_MID, width=6, height=6,
                                    highlightthickness=0)
        self._live_dot.pack(side='left', padx=6)
        self._live_oval = self._live_dot.create_oval(0, 0, 5, 5,
                                                      fill=TEXT_SOFT, outline='')
        self._live_lbl = tk.Label(hdr, text='PAUSED', bg=BG_MID, fg=TEXT_SOFT,
                                   font=('Courier', 7))
        self._live_lbl.pack(side='left')
        tk.Button(hdr, text='Clear', bg=BG_MID, fg=TEXT_SOFT, relief='flat',
                  font=('Helvetica', 8), command=self._clear_log,
                  cursor='hand2').pack(side='right')

        self.log_text = tk.Text(log, bg=BG_MID, fg=TEXT_MID,
                                 font=_F['sm'], relief='flat',
                                 state='disabled', wrap='word',
                                 selectbackground=BORDER)
        scr = tk.Scrollbar(log, command=self.log_text.yview)
        self.log_text.configure(yscrollcommand=scr.set)
        scr.pack(side='right', fill='y')
        self.log_text.pack(fill='both', expand=True, padx=14, pady=(0, 8))

        self.log_text.tag_configure('step', foreground=TEXT_SOFT)
        self.log_text.tag_configure('ok',   foreground=TEXT_MID)
        self.log_text.tag_configure('suc',  foreground='#166534')
        self.log_text.tag_configure('warn', foreground=AMBER)
        self.log_text.tag_configure('err',  foreground=ACCENT)

    # ── Canvas rendering ─────────────────────────────────────────────────

    def _refresh_canvas(self):
        self.canvas.delete('all')
        city  = self.sim.city
        roads = self.ov_roads.get()
        amb   = self.ov_amb.get()
        heat  = self.ov_heat.get()

        zones = {}
        if amb and city.ambulance_positions:
            zones = compute_coverage_zones(city)

        # ── Isometric grid cells ──────────────────────────────────────
        for r in range(N):
            for c in range(N):
                pos  = (r, c)
                node = city.nodes[pos]
                poly = _iso_polygon(r, c)

                fill   = COLORS.get(node.node_type, COLORS['E'])
                border = CELL_BORDERS.get(node.node_type, BORDER)

                if heat:
                    fill   = {'High': '#fca5a5', 'Medium': '#fdba74',
                              'Low': '#86efac'}.get(node.risk_level, fill)
                    border = {'High': ACCENT, 'Medium': AMBER,
                              'Low': GREEN}.get(node.risk_level, border)

                if amb and zones:
                    zone_colors = ['#bfdbfe', '#bbf7d0', '#fde68a']
                    fill   = zone_colors[zones.get(pos, 0) % 3]
                    border = BLUE

                self.canvas.create_polygon(poly, fill=fill, outline=border,
                                            width=1.5, tags='cell')

                cx, cy = _iso_center(r, c)
                self.canvas.create_text(cx, cy, text=node.node_type,
                                         fill=_darken(fill),
                                         font=_F['cell'], tags='label')

        # ── MST road overlay ──────────────────────────────────────────
        if roads and city.mst_edges:
            for key in city.mst_edges:
                edge = city.edges.get(key)
                if not edge:
                    continue
                x1, y1 = _iso_center(*edge.u)
                x2, y2 = _iso_center(*edge.v)
                color = ACCENT if edge.blocked else BLUE
                self.canvas.create_line(x1, y1, x2, y2, fill=color,
                                         width=2 if edge.blocked else 1.5,
                                         dash=(4, 2) if edge.blocked else None,
                                         tags='road')

        # ── Blocked-road X markers ────────────────────────────────────
        for edge in city.edges.values():
            if edge.blocked:
                mx = (_iso_center(*edge.u)[0] + _iso_center(*edge.v)[0]) / 2
                my = (_iso_center(*edge.u)[1] + _iso_center(*edge.v)[1]) / 2
                d = 4
                self.canvas.create_line(mx-d, my-d, mx+d, my+d,
                                         fill=ACCENT, width=2.5, tags='block')
                self.canvas.create_line(mx+d, my-d, mx-d, my+d,
                                         fill=ACCENT, width=2.5, tags='block')

        # ── A* route path ─────────────────────────────────────────────
        route = self.sim.current_route
        if len(route) > 1:
            pts = []
            for pos in route:
                pts.extend(_iso_center(*pos))
            self.canvas.create_line(pts, fill=BLUE, width=2,
                                     dash=(6, 3), tags='route')

        # ── Civilians ─────────────────────────────────────────────────
        _cr = max(6, TW // 10)
        for pos in self.sim.civilians:
            cx, cy = _iso_center(*pos)
            rescued = pos in self.sim.rescued
            self.canvas.create_oval(cx-_cr, cy-_cr, cx+_cr, cy+_cr,
                                     fill='#86efac' if rescued else '#fef08a',
                                     outline=TEXT, width=1.5, tags='civ')
            if not rescued:
                self.canvas.create_text(cx, cy, text='!', fill=TEXT,
                                         font=_F['xsb'], tags='civ')

        # ── Ambulances ────────────────────────────────────────────────
        _ar = max(8, TW // 8)
        zone_labels = ['A', 'B', 'C']
        for i, pos in enumerate(city.ambulance_positions):
            cx, cy = _iso_center(*pos)
            self.canvas.create_oval(cx-_ar, cy-_ar, cx+_ar, cy+_ar,
                                     fill='#f97316', outline='white',
                                     width=2, tags='amb')
            self.canvas.create_text(cx, cy, text='+', fill='white',
                                     font=_F['cellbig'], tags='amb')
            if amb:
                self.canvas.create_text(cx+_ar+5, cy-_ar,
                                         text=f'Zone {zone_labels[i % 3]}',
                                         fill=BLUE, font=_F['xs'], tags='amb')

        # ── Medical response team ──────────────────────────────────────
        if self.sim.team_pos:
            _tr = max(9, TW // 8)
            cx, cy = _iso_center(*self.sim.team_pos)
            self.canvas.create_rectangle(cx-_tr, cy-_tr, cx+_tr, cy+_tr,
                                          fill='white', outline=ACCENT,
                                          width=2.5, tags='team')
            self.canvas.create_text(cx, cy, text='✚', fill=ACCENT,
                                     font=_F['cellbig'], tags='team')

        # ── Flood-mode instruction banner ──────────────────────────────
        if self._flood_mode:
            cw = self.canvas.winfo_width() or GRID_W
            self.canvas.create_rectangle(
                cw//2 - 160, 6, cw//2 + 160, 26,
                fill='#1e3a5f', outline=BLUE, tags='banner')
            self.canvas.create_text(
                cw//2, 16, text='Click a cell to flood its nearest road',
                fill='#e0f2fe', font=('Courier', 9), tags='banner')

        # ── Node detail popup ──────────────────────────────────────────
        if self._selected:
            self._draw_popup(*self._selected)

        # ── Grid label update ──────────────────────────────────────────
        parts = []
        if roads: parts.append('ROAD NETWORK')
        if amb:   parts.append('AMBULANCE COVERAGE')
        if heat:  parts.append('CRIME RISK HEATMAP')
        self._grid_lbl.configure(
            text=('OVERLAY — ' + ' + '.join(parts)) if parts else 'GRID VIEW — DEFAULT')

    def _draw_popup(self, r, c):
        city = self.sim.city
        pos  = (r, c)
        if pos not in city.nodes:
            return
        node = city.nodes[pos]

        cx, cy = _iso_center(r, c)
        pw, ph = 162, 100
        px = cx + 16
        py = cy - ph - 8
        cw = self.canvas.winfo_width() or GRID_W
        if px + pw > cw - 4:
            px = cx - pw - 16
        if py < 4:
            py = cy + TH + 4

        self.canvas.create_rectangle(px+3, py+3, px+pw+3, py+ph+3,
                                      fill='#c8c2b8', outline='', tags='popup')
        self.canvas.create_rectangle(px, py, px+pw, py+ph,
                                      fill=BG, outline=BORDER_STR,
                                      width=1.5, tags='popup')
        self.canvas.create_line(px, py+22, px+pw, py+22,
                                 fill=BORDER, tags='popup')

        self.canvas.create_rectangle(px+8, py+6, px+18, py+16,
                                      fill=COLORS.get(node.node_type, BG),
                                      outline=CELL_BORDERS.get(node.node_type, BORDER),
                                      width=1.5, tags='popup')
        self.canvas.create_text(px+24, py+11, anchor='w',
                                 text=TYPES.get(node.node_type, '?'),
                                 font=('Helvetica', 9, 'bold'),
                                 fill=TEXT, tags='popup')
        self.canvas.create_text(px+pw-6, py+11, anchor='e',
                                 text=f'({r},{c})',
                                 font=('Courier', 8),
                                 fill=TEXT_SOFT, tags='popup')

        risk_color = {'High': ACCENT, 'Medium': AMBER, 'Low': GREEN}
        rows = [
            ('Population',  str(node.population),       TEXT),
            ('Risk Level',  node.risk_level,             risk_color.get(node.risk_level, TEXT)),
            ('Risk Index',  f'{node.risk_index:.2f}',    TEXT),
            ('Accessible',  'Yes' if node.accessible else 'No',
             GREEN if node.accessible else ACCENT),
        ]
        y = py + 27
        for label, value, val_color in rows:
            self.canvas.create_line(px, y+14, px+pw, y+14,
                                     fill=BORDER, tags='popup')
            self.canvas.create_text(px+8, y+7, anchor='w', text=label,
                                     font=('Helvetica', 8), fill=TEXT_SOFT,
                                     tags='popup')
            self.canvas.create_text(px+pw-8, y+7, anchor='e', text=value,
                                     font=('Courier', 8), fill=val_color,
                                     tags='popup')
            y += 15

        self.canvas.create_text(px+pw-6, py+ph-5, anchor='e',
                                 text='click elsewhere to close',
                                 font=('Courier', 7), fill=TEXT_SOFT,
                                 tags='popup')

    # ── Simulation callbacks ─────────────────────────────────────────────

    def _on_initialize(self):
        self._stop_auto()
        self.sim.reset()
        self.sim.city.subscribe(self._refresh_canvas)
        self.sim.initialize()
        self._flush_logs()
        self._refresh_canvas()
        self._update_topbar(running=False)

    def _on_step(self):
        if not self.sim.initialized:
            self._on_initialize()
        result = self.sim.step()
        self._flush_logs()
        self._refresh_canvas()
        self._update_topbar(running=False)
        if result.get('done'):
            self._stop_auto()

    def _on_run(self):
        if not self.sim.initialized:
            self._on_initialize()
        self._run_btn.configure(bg='#166534', fg=BG)
        self._auto_step()

    def _on_pause(self):
        self._stop_auto()
        self._run_btn.configure(bg=BG_DARK, fg=BG)
        self._update_topbar(running=False)

    def _auto_step(self):
        result = self.sim.step()
        self._flush_logs()
        self._refresh_canvas()
        self._update_topbar(running=True)
        if result.get('done'):
            self._stop_auto()
            self._run_btn.configure(bg=BG_DARK, fg=BG)
        else:
            delay = max(100, int(900 / (self._speed.get() or 1.0)))
            self._auto_id = self.after(delay, self._auto_step)

    def _stop_auto(self):
        if self._auto_id is not None:
            self.after_cancel(self._auto_id)
            self._auto_id = None

    def _on_reset(self):
        self._stop_auto()
        self.sim.reset()
        self.sim.city.subscribe(self._refresh_canvas)
        self._log_count  = 0
        self._clear_log()
        self._selected   = None
        self._flood_mode = False
        self._risk_mult  = False
        self._flood_btn.configure(bg='#f8faff', fg='#93afd4')
        self._risk_btn.configure(bg='#fffdf7',  fg='#c4a458')
        self._run_btn.configure(bg=BG_DARK, fg=BG)
        self._refresh_canvas()
        self._update_topbar(running=False)

    def _on_speed_change(self, _=None):
        v = self._speed.get()
        self._spd_lbl.configure(text=f'×{v:.2g}')

    # ── Override callbacks ───────────────────────────────────────────────

    def _on_flood(self):
        self._flood_mode = not self._flood_mode
        if self._flood_mode:
            self._flood_btn.configure(bg='#dbeafe', fg='#1e40af')
            self._append_log('--', 'FLOOD MODE: click any cell to flood adjacent road', 'warn')
        else:
            self._flood_btn.configure(bg='#f8faff', fg='#93afd4')
            self._append_log('--', 'Flood mode deactivated', 'ok')
        self._refresh_canvas()

    def _on_risk(self):
        self._risk_mult = not self._risk_mult
        city = self.sim.city
        mult = 2.0 if self._risk_mult else 0.5
        for node in city.nodes.values():
            node.risk_index = min(1.0, node.risk_index * mult)
            node.risk_level = ('High'   if node.risk_index > 0.6 else
                               'Medium' if node.risk_index > 0.3 else 'Low')
        if self._risk_mult:
            self._risk_btn.configure(bg='#fef3c7', fg='#78350f')
            self._append_log('--', 'Risk multiplier ×2 applied — ML scores elevated', 'warn')
        else:
            self._risk_btn.configure(bg='#fffdf7', fg='#c4a458')
            self._append_log('--', 'Risk multiplier removed', 'ok')
        self._refresh_canvas()

    # ── Click handler ────────────────────────────────────────────────────

    def _on_click(self, event):
        r, c = _screen_to_cell(event.x, event.y)

        if r < 0 or c < 0:
            self._selected = None
            self._refresh_canvas()
            return

        if self._flood_mode:
            pos  = (r, c)
            city = self.sim.city
            for nbr, _ in city.neighbors(pos, only_open=False):
                edge_key = (min(pos, nbr), max(pos, nbr))
                if edge_key in city.edges and not city.edges[edge_key].blocked:
                    city.block_road(pos, nbr)
                    step = str(self.sim.step_number).zfill(2)
                    self._append_log(step, f'Road {pos}→{nbr} flooded (manual override)', 'err')
                    self._flood_mode = False
                    self._flood_btn.configure(bg='#f8faff', fg='#93afd4')
                    break
            self._refresh_canvas()
            return

        if self._selected == (r, c):
            self._selected = None
        else:
            self._selected = (r, c)
        self._refresh_canvas()

    # ── Log helpers ──────────────────────────────────────────────────────

    def _flush_logs(self):
        new = self.sim.log[self._log_count:]
        for entry in new:
            tag  = {'success': 'suc', 'warn': 'warn',
                    'danger': 'err'}.get(entry['level'], 'ok')
            step = str(entry['step']).zfill(2) if entry['step'] else '--'
            self._append_log(step, entry['message'], tag)
        self._log_count = len(self.sim.log)

    def _append_log(self, step: str, message: str, tag: str = 'ok'):
        self.log_text.configure(state='normal')
        self.log_text.insert('end', f' {step:>2}  ', 'step')
        self.log_text.insert('end', message + '\n', tag)
        self.log_text.see('end')
        self.log_text.configure(state='disabled')

    def _clear_log(self):
        self.log_text.configure(state='normal')
        self.log_text.delete('1.0', 'end')
        self.log_text.configure(state='disabled')
        self._log_count = 0

    # ── Topbar update ────────────────────────────────────────────────────

    def _update_topbar(self, running: bool = False):
        s   = self.sim.step_number
        col = GREEN if running else '#6b7280'
        self._step_lbl.configure(text=f'{str(s).zfill(2)} / 20')
        self._prog_bg.coords(self._prog_fill, 0, 0, int(self._prog_w * s / 20), 4)
        self._prog_bg.itemconfig(self._prog_fill, fill=col)
        self._dot.itemconfig(self._dot_oval, fill=col)
        n = len(self.sim.city.ambulance_positions)
        self._units_lbl.configure(text=f'{n} UNITS')
        live_col = GREEN if running else TEXT_SOFT
        self._live_dot.itemconfig(self._live_oval, fill=live_col)
        self._live_lbl.configure(text='LIVE' if running else 'PAUSED')


# ── Sidebar widget helpers ───────────────────────────────────────────────

def _sec(parent, label: str):
    """Section heading: hamburger icon + uppercase label + rule line."""
    f = tk.Frame(parent, bg=BG_MID)
    f.pack(fill='x', padx=16, pady=(12, 6))
    ico = tk.Canvas(f, bg=BG_MID, width=14, height=14, highlightthickness=0)
    ico.pack(side='left', padx=(0, 6))
    for yy in (2, 6, 10):
        ico.create_rectangle(1, yy, 12 if yy < 10 else 8, yy+2,
                              fill=TEXT_MID, outline='')
    tk.Label(f, text=label.upper(), bg=BG_MID, fg=TEXT_MID,
             font=_F['smb']).pack(side='left')
    tk.Frame(f, bg=BORDER, height=1).pack(
        side='left', fill='x', expand=True, padx=(6, 0), pady=6)


def _chk(parent, label: str, var: tk.BooleanVar, command, px: int = 16):
    """Checkbox toggle row."""
    f = tk.Frame(parent, bg=BG_MID, cursor='hand2')
    f.pack(fill='x', padx=px, pady=3)

    box = tk.Canvas(f, width=15, height=15, bg=BG_MID, highlightthickness=0)
    box.pack(side='left', padx=(0, 8))
    lbl = tk.Label(f, text=label, bg=BG_MID, fg=TEXT_MID,
                   font=_F['md'], anchor='w')
    lbl.pack(side='left')

    def _redraw(*_):
        box.delete('all')
        if var.get():
            box.create_rectangle(1, 1, 14, 14, outline=TEXT,
                                  fill=TEXT, width=1.5)
            box.create_line(3, 8, 6, 12, fill='white', width=1.8)
            box.create_line(6, 12, 12, 4, fill='white', width=1.8)
        else:
            box.create_rectangle(1, 1, 14, 14, outline=BORDER_STR,
                                  fill='', width=1.5)

    def _click(*_):
        var.set(not var.get())
        _redraw()
        command()

    for w in (box, lbl, f):
        w.bind('<Button-1>', _click)
    var.trace_add('write', _redraw)
    _redraw()


def _btn(parent, text: str, command, dark: bool = False) -> tk.Button:
    return tk.Button(
        parent, text=text, command=command,
        bg=BG_DARK if dark else BG_MID,
        fg=BG     if dark else TEXT_MID,
        relief='flat', font=_F['mdb'],
        padx=12, pady=6, cursor='hand2',
        activebackground='#333' if dark else BORDER,
        activeforeground=BG if dark else TEXT,
    )


def _gap(parent, h: int = 8):
    tk.Frame(parent, bg=BG_MID, height=h).pack(fill='x')
