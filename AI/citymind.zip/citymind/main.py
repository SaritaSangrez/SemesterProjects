"""
main.py  —  CityMind entry point

Run:  python main.py
"""
import sys, os
sys.path.insert(0, os.path.dirname(__file__))

from gui.app import CityMindApp

if __name__ == '__main__':
    app = CityMindApp()
    app.mainloop()
