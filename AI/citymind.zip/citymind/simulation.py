"""
simulation.py  —  20-Step City Simulation Orchestrator

Ties all five challenge modules together through the shared CityGraph.
All modules operate on the same graph instance — a change in one is
immediately visible to all others.

Simulation lifecycle:
  initialize() — run all setup phases once (challenges 1, 2, 5, 3, then 4 setup)
  step()        — advance by one step: random events + route maintenance
"""

import random
import sys, os
sys.path.insert(0, os.path.dirname(__file__))

from city_graph import CityGraph
from algorithms.csp_layout        import solve_layout, check_constraints
from algorithms.mst_roads          import build_road_network, mst_total_cost
from algorithms.genetic_ambulance  import place_ambulances
from algorithms.astar_routing      import route_to_civilians, recalculate_route
from algorithms.crime_prediction   import run_crime_prediction


class CitySimulation:
    """Orchestrates the full CityMind simulation over 20 steps."""

    MAX_STEPS = 20
    FLOOD_PROB = 0.30     # 30% chance of a road flooding each step
    AMB_REPLAN_EVERY = 5  # re-optimise ambulance positions every N steps

    def __init__(self, rows: int = 10, cols: int = 10):
        self.city          = CityGraph(rows, cols)
        self.step_number   = 0
        self.running       = False
        self.initialized   = False

        # Challenge 4 state
        self.team_pos:         tuple       = None
        self.civilians:        list        = []
        self.remaining_civs:   list        = []
        self.current_route:    list        = []
        self.rescued:          list        = []

        # Event log — list of dicts: {step, message, level}
        self.log: list = []

    # ── Initialisation ─────────────────────────────────────────────────

    def initialize(self):
        """Run all setup phases. Must be called before step()."""
        self._log("CityMind initialising …", 'info')

        # ── Challenge 1: CSP Layout Planning ───────────────────────────
        self._log("Challenge 1 · CSP Layout Planning (backtracking) …", 'info')
        violations = solve_layout(self.city, seed=42)
        if not violations:
            self._log("  Layout valid — all CSP constraints satisfied ✓", 'success')
        else:
            for rule, items in violations.items():
                self._log(f"  ⚠ {rule}: {len(items)} issue(s)", 'warn')

        # ── Challenge 2: Road Network (Kruskal's MST) ───────────────────
        self._log("Challenge 2 · Road Network (Kruskal's MST) …", 'info')
        n_roads = build_road_network(self.city)
        cost    = mst_total_cost(self.city)
        self._log(f"  MST built — {n_roads} roads, total cost {cost} ✓", 'success')

        # ── Challenge 5: Crime Prediction (K-Means + Decision Tree) ─────
        self._log("Challenge 5 · Crime Prediction (K-Means + Decision Tree) …", 'info')
        preds = run_crime_prediction(self.city, seed=7)
        high   = sum(1 for v in preds.values() if v == 'High')
        medium = sum(1 for v in preds.values() if v == 'Medium')
        low    = sum(1 for v in preds.values() if v == 'Low')
        self._log(f"  Risk map: {high} High · {medium} Medium · {low} Low ✓", 'success')

        # ── Challenge 3: Ambulance Placement (Genetic Algorithm) ────────
        self._log("Challenge 3 · Ambulance Placement (Genetic Algorithm) …", 'info')
        amb_pos = place_ambulances(self.city, seed=0)
        self._log(f"  Ambulances placed at {amb_pos} ✓", 'success')

        # ── Challenge 4: Emergency Route Setup (A*) ─────────────────────
        self._log("Challenge 4 · Emergency Routing (A*) setup …", 'info')
        hospitals = self.city.get_by_type('H')
        self.team_pos = hospitals[0] if hospitals else (0, 0)

        residentials = self.city.get_by_type('R')
        random.seed(123)
        self.civilians = random.sample(residentials, min(5, len(residentials)))
        self.remaining_civs = list(self.civilians)

        self.current_route, cost = route_to_civilians(
            self.city, self.team_pos, self.remaining_civs
        )
        self._log(f"  Team at {self.team_pos} · {len(self.civilians)} civilians "
                  f"· route cost {cost:.2f} ✓", 'success')

        self.initialized = True
        self._log("─" * 48, 'info')
        self._log("System ready. Use Step or Run to start simulation.", 'info')

    # ── Per-step logic ──────────────────────────────────────────────────

    def step(self) -> dict:
        """
        Advance the simulation by one step.
        Returns a summary dict used by the GUI.
        """
        if not self.initialized:
            self.initialize()

        if self.step_number >= self.MAX_STEPS:
            self._log("Simulation complete (20 steps).", 'success')
            return {'done': True, 'step': self.step_number}

        self.step_number += 1
        events = []

        # ── Random road flooding (Challenge 4 trigger) ─────────────────
        route_exposed = self.current_route
        if random.random() < self.FLOOD_PROB and len(route_exposed) > 1:
            idx = random.randint(0, len(route_exposed) - 2)
            u, v = route_exposed[idx], route_exposed[idx + 1]

            if self.city.block_road(u, v):
                self._log(f"Step {self.step_number}: Road {u}→{v} flooded!", 'danger')
                events.append({'type': 'flood', 'u': u, 'v': v})

                # Immediate A* recalculation from current position
                new_route, new_cost = recalculate_route(
                    self.city, self.team_pos, self.remaining_civs
                )
                if new_route:
                    self.current_route = new_route
                    self._log(f"  Route recalculated via A* — new cost {new_cost:.2f}",
                              'warn')
                    events.append({'type': 'reroute', 'path': new_route})
                else:
                    self._log("  ⚠ No route available! Some civilians unreachable.",
                              'danger')

        # ── Advance team one step along route ──────────────────────────
        if len(self.current_route) > 1:
            self.team_pos      = self.current_route[1]
            self.current_route = self.current_route[1:]
        elif self.current_route:
            self.team_pos = self.current_route[0]

        # Check if team reached a civilian
        if self.team_pos in self.remaining_civs:
            self.remaining_civs.remove(self.team_pos)
            self.rescued.append(self.team_pos)
            self._log(f"Step {self.step_number}: Civilian rescued at {self.team_pos} ✓",
                      'success')
            events.append({'type': 'rescue', 'pos': self.team_pos})

        # ── Periodic ambulance re-optimisation ─────────────────────────
        if self.step_number % self.AMB_REPLAN_EVERY == 0:
            self._log(f"Step {self.step_number}: Re-optimising ambulance positions (GA) …",
                      'info')
            new_pos = place_ambulances(self.city, seed=self.step_number)
            self._log(f"  New positions: {new_pos}", 'success')
            events.append({'type': 'amb_replan', 'positions': new_pos})

        self._log(f"Step {self.step_number}: team at {self.team_pos} · "
                  f"{len(self.remaining_civs)} civilian(s) remaining.", 'info')

        return {
            'done':       self.step_number >= self.MAX_STEPS,
            'step':       self.step_number,
            'team_pos':   self.team_pos,
            'route':      self.current_route[:],
            'civilians':  self.civilians[:],
            'remaining':  self.remaining_civs[:],
            'rescued':    self.rescued[:],
            'events':     events,
        }

    # ── Reset ───────────────────────────────────────────────────────────

    def reset(self):
        """Rebuild the city graph and clear all state."""
        self.city          = CityGraph(self.city.rows, self.city.cols)
        self.step_number   = 0
        self.initialized   = False
        self.team_pos      = None
        self.civilians     = []
        self.remaining_civs = []
        self.current_route = []
        self.rescued       = []
        self.log           = []

    # ── Helpers ─────────────────────────────────────────────────────────

    def _log(self, message: str, level: str = 'info'):
        self.log.append({'step': self.step_number, 'message': message, 'level': level})
