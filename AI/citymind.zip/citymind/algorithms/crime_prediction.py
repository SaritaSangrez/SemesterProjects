"""
Challenge 5 — Crime Risk Prediction and Integration
Algorithms: K-Means Clustering (unsupervised) + Decision Tree (supervised)

Pipeline:
  1. K-Means: group the 100 neighbourhoods into 3 clusters based on
     population density and industrial proximity — no labels needed.
  2. Synthetic data: generate crime incident rates using domain logic
     (dense + industrial → higher crime), producing labelled training data.
  3. Decision Tree: train a classifier to predict risk level
     (High / Medium / Low) from the node's features.
  4. Integration: feed predicted risk back into city.nodes[pos].risk_index,
     which A* and the ambulance GA use as a cost multiplier.

Why two different learning types?
  K-Means is UNSUPERVISED — it finds structure in unlabelled data.
  Decision Tree is SUPERVISED — it learns from labelled examples.
  Together they form a realistic ML pipeline: cluster → label generation
  → classification → action (routing cost adjustment).
"""

import math
import random
import sys
sys.path.insert(0, '..')
from city_graph import CityGraph


# ── Entry point ─────────────────────────────────────────────────────────

def run_crime_prediction(city: CityGraph, seed: int = 7) -> dict:
    """
    Full pipeline. Returns {pos: risk_level} and updates the city graph.
    """
    random.seed(seed)
    positions = list(city.nodes.keys())

    # Step 1: extract feature vectors
    features = [_extract_features(city, pos) for pos in positions]

    # Step 2: K-Means clustering (k=3, no labels needed)
    cluster_labels = kmeans(features, k=3, seed=seed)

    # Step 3: generate synthetic labelled crime data
    X, y = _generate_labeled_data(city, positions, features, cluster_labels)

    # Step 4: train Decision Tree
    tree = DecisionTree(max_depth=4)
    tree.fit(X, y)

    # Step 5: predict risk for every node and update city graph
    predictions = {}
    for i, pos in enumerate(positions):
        label = tree.predict(X[i])
        index = {'Low': 0.1, 'Medium': 0.4, 'High': 0.8}[label]
        predictions[pos] = label
        city.set_risk(pos, label, index)

    city.notify()   # single notification after bulk update
    return predictions


def _extract_features(city: CityGraph, pos: tuple) -> list:
    """
    Feature vector per node: [pop_density, industrial_proximity, type_code]
    All values normalised to [0, 1].
    """
    node = city.nodes[pos]
    industrials = city.get_by_type('I')

    # Population density normalised
    pop_norm = min(node.population / 2000.0, 1.0)

    # Proximity to industrial zones (closer → higher value)
    if industrials:
        min_dist = min(city.manhattan(pos, ip) for ip in industrials)
        ind_prox = 1.0 / (1.0 + min_dist)
    else:
        ind_prox = 0.0

    # Type encoded as a number
    type_code = {'R': 0.8, 'I': 0.9, 'H': 0.2, 'S': 0.3,
                 'P': 0.5, 'A': 0.3, 'E': 0.1}.get(node.node_type, 0.5)

    return [pop_norm, ind_prox, type_code]


# ── K-Means ──────────────────────────────────────────────────────────────

def kmeans(data: list, k: int = 3, max_iter: int = 200, seed: int = 0) -> list:
    """
    K-Means clustering — groups data points by similarity without labels.

    Steps:
      1. Randomly pick k data points as initial centroids.
      2. Assign every point to its nearest centroid.
      3. Move each centroid to the mean of its assigned points.
      4. Repeat 2–3 until no assignments change (convergence).

    Returns a list of cluster labels (0 … k-1), one per data point.
    """
    random.seed(seed)
    n   = len(data)
    dim = len(data[0])

    # Initialise centroids from random data points
    centroids = [data[i][:] for i in random.sample(range(n), k)]
    labels    = [0] * n

    for _ in range(max_iter):
        # Assignment step: each point → nearest centroid
        new_labels = []
        for point in data:
            dists = [_euclidean(point, c) for c in centroids]
            new_labels.append(dists.index(min(dists)))

        if new_labels == labels:
            break   # converged
        labels = new_labels

        # Update step: move centroids to cluster means
        for j in range(k):
            members = [data[i] for i in range(n) if labels[i] == j]
            if members:
                centroids[j] = [
                    sum(m[d] for m in members) / len(members)
                    for d in range(dim)
                ]

    return labels


def _euclidean(a: list, b: list) -> float:
    return math.sqrt(sum((x - y) ** 2 for x, y in zip(a, b)))


# ── Synthetic data generation ────────────────────────────────────────────

def _generate_labeled_data(city, positions, features, cluster_labels):
    """
    Assign High / Medium / Low risk labels using domain logic.

    Dense residential areas near industrial zones have higher crime rates.
    This produces a labelled dataset to train the Decision Tree.
    """
    X, y = [], []
    for i, pos in enumerate(positions):
        feat  = features[i]
        node  = city.nodes[pos]
        pop   = feat[0]
        ind   = feat[1]

        # Crime score: weighted combination of risk factors + a little noise
        score = pop * 0.5 + ind * 0.4 + random.uniform(0, 0.1)

        # Residential and Industrial zones are statistically higher-crime
        if node.node_type == 'R':
            score += 0.12
        elif node.node_type == 'I':
            score += 0.18

        # Assign label based on score thresholds
        if score > 0.55:
            label = 'High'
        elif score > 0.28:
            label = 'Medium'
        else:
            label = 'Low'

        X.append(feat)
        y.append(label)

    return X, y


# ── Decision Tree ─────────────────────────────────────────────────────────

class DecisionTree:
    """
    Binary Decision Tree classifier built from scratch.

    At each node we find the feature + threshold that maximises
    Information Gain (reduction in entropy after the split).
    We keep splitting until max_depth is reached or the node is pure.

    Entropy of a label set S:
        H(S) = - Σ p_c * log₂(p_c)   where p_c = fraction of class c in S

    Information Gain of a split:
        IG = H(parent) - (|left|/|parent|)*H(left) - (|right|/|parent|)*H(right)
    """

    def __init__(self, max_depth: int = 4):
        self.max_depth = max_depth
        self.root = None

    def fit(self, X: list, y: list):
        self.root = self._build(X, y, depth=0)

    def predict(self, x: list) -> str:
        return self._walk(self.root, x)

    # ── Private ──────────────────────────────────────────────────────────

    def _build(self, X, y, depth):
        """Recursively build the tree by finding the best split."""
        # Base cases
        if not y or depth >= self.max_depth or len(set(y)) == 1:
            return _majority(y)

        feat, thresh, gain = self._best_split(X, y)
        if gain <= 0:
            return _majority(y)

        left_X,  left_y  = [], []
        right_X, right_y = [], []
        for xi, yi in zip(X, y):
            if xi[feat] <= thresh:
                left_X.append(xi);  left_y.append(yi)
            else:
                right_X.append(xi); right_y.append(yi)

        return {
            'feat':   feat,
            'thresh': thresh,
            'left':   self._build(left_X,  left_y,  depth + 1),
            'right':  self._build(right_X, right_y, depth + 1),
        }

    def _walk(self, node, x):
        if not isinstance(node, dict):
            return node   # leaf: return the class label
        if x[node['feat']] <= node['thresh']:
            return self._walk(node['left'], x)
        return self._walk(node['right'], x)

    def _best_split(self, X, y):
        """Try every feature / threshold combo; return the one with highest IG."""
        best_feat, best_thresh, best_gain = 0, 0.0, 0.0
        parent_h = _entropy(y)

        for feat in range(len(X[0])):
            values     = sorted({xi[feat] for xi in X})
            thresholds = [(values[i] + values[i+1]) / 2 for i in range(len(values)-1)]
            for thresh in thresholds:
                left_y  = [yi for xi, yi in zip(X, y) if xi[feat] <= thresh]
                right_y = [yi for xi, yi in zip(X, y) if xi[feat] > thresh]
                if not left_y or not right_y:
                    continue
                n = len(y)
                gain = parent_h - (
                    (len(left_y)  / n) * _entropy(left_y) +
                    (len(right_y) / n) * _entropy(right_y)
                )
                if gain > best_gain:
                    best_gain, best_feat, best_thresh = gain, feat, thresh

        return best_feat, best_thresh, best_gain


def _entropy(labels: list) -> float:
    """Shannon entropy of a list of class labels."""
    if not labels:
        return 0.0
    total  = len(labels)
    counts = {}
    for lbl in labels:
        counts[lbl] = counts.get(lbl, 0) + 1
    return -sum((c / total) * math.log2(c / total) for c in counts.values())


def _majority(labels: list) -> str:
    if not labels:
        return 'Low'
    counts = {}
    for lbl in labels:
        counts[lbl] = counts.get(lbl, 0) + 1
    return max(counts, key=counts.get)
