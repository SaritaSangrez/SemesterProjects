"""
Challenge 2 — Road Network Optimization
Algorithm: Kruskal's Minimum Spanning Tree + redundancy edges

Goal: Connect all city locations using the minimum total road cost.
Safety requirement: At least TWO independent paths must always exist
between the primary Hospital and every Ambulance Depot.

Why Kruskal's MST?
  We are choosing a subset of edges (roads to build) that keeps all nodes
  connected with minimum total cost. This is exactly the Minimum Spanning
  Tree problem. Kruskal's is O(E log E) — fast and easy to trace by hand.
  Prim's was also considered; both give identical MSTs, but Kruskal's is
  simpler to explain for a grid graph.

Redundancy:
  An MST is a tree (no cycles), so there is exactly ONE path between any
  two nodes. If any road on that path fails, the nodes disconnect — unsafe
  for hospitals. We add a minimum-cost extra edge that creates a second
  independent route between Hospital and Ambulance Depot.
"""

import sys
sys.path.insert(0, '..')
from city_graph import CityGraph


# ── Union-Find ─────────────────────────────────────────────────────────

class UnionFind:
    """
    Union-Find (Disjoint Set Union) data structure.

    Supports two operations:
      find(x)    — which group does x belong to?
      union(x,y) — merge the groups containing x and y.

    Used by Kruskal's to check if adding an edge would create a cycle.
    """

    def __init__(self, elements):
        self.parent = {e: e for e in elements}
        self.rank   = {e: 0 for e in elements}

    def find(self, x):
        """Return the root of x's group (with path compression)."""
        if self.parent[x] != x:
            self.parent[x] = self.find(self.parent[x])  # path compression
        return self.parent[x]

    def union(self, x, y) -> bool:
        """
        Merge groups. Returns True if they were separate (edge is useful),
        False if they were already in the same group (would create a cycle).
        """
        px, py = self.find(x), self.find(y)
        if px == py:
            return False  # same group → adding this edge creates a cycle
        # Union by rank: attach smaller tree under larger tree
        if self.rank[px] < self.rank[py]:
            px, py = py, px
        self.parent[py] = px
        if self.rank[px] == self.rank[py]:
            self.rank[px] += 1
        return True


# ── Kruskal's MST ──────────────────────────────────────────────────────

def build_road_network(city: CityGraph) -> int:
    """
    Run Kruskal's algorithm on the city graph.

    Steps:
      1. Sort all possible roads by cost (cheapest first).
      2. Add a road if it connects two previously disconnected areas.
      3. Stop when all locations are connected (n-1 roads added).
      4. Add extra roads for Hospital↔AmbulanceDepot redundancy.

    Updates city.mst_edges and returns the number of MST edges built.
    """
    positions = list(city.nodes.keys())
    uf = UnionFind(positions)

    # Step 1: sort edges cheapest-first
    sorted_edges = sorted(city.edges.values(), key=lambda e: e.base_cost)

    mst_keys = []

    # Step 2 & 3: Kruskal's greedy edge selection
    for edge in sorted_edges:
        if uf.union(edge.u, edge.v):          # False if would form a cycle
            mst_keys.append(edge.key)
        if len(mst_keys) == len(positions) - 1:
            break                             # MST complete (n-1 edges)

    city.mst_edges = set(mst_keys)

    # Step 4: add redundant paths
    _add_redundancy(city)

    return len(city.mst_edges)


def _add_redundancy(city: CityGraph):
    """
    Ensure ≥ 2 independent paths exist between each Hospital
    and each Ambulance Depot by adding one extra (non-MST) edge
    adjacent to the H→Depot path.

    Any non-MST edge touching a node on the path creates a cycle,
    giving at least one alternative route through that node.
    """
    hospitals = city.get_by_type('H')
    depots    = city.get_by_type('A')

    if not hospitals or not depots:
        return

    for hosp in hospitals:
        for depot in depots:
            mst_path = _path_in_mst(city, hosp, depot)
            if len(mst_path) < 2:
                continue

            path_set = set(mst_path)

            # Find cheapest non-MST edge touching any node on the path
            best_key  = None
            best_cost = float('inf')

            for key, edge in city.edges.items():
                if key in city.mst_edges:
                    continue
                if edge.u in path_set or edge.v in path_set:
                    if edge.base_cost < best_cost:
                        best_cost = edge.base_cost
                        best_key  = key

            if best_key:
                city.mst_edges.add(best_key)


def _path_in_mst(city: CityGraph, start: tuple, goal: tuple) -> list:
    """BFS on MST edges only. Returns list of node positions forming the path."""
    from collections import deque
    visited = {start}
    queue   = deque([(start, [start])])

    while queue:
        pos, path = queue.popleft()
        if pos == goal:
            return path
        for nbr, _ in city.neighbors(pos, only_open=False):
            edge_key = (min(pos, nbr), max(pos, nbr))
            if nbr not in visited and edge_key in city.mst_edges:
                visited.add(nbr)
                queue.append((nbr, path + [nbr]))
    return []


def _cheapest_bypass_edge(city: CityGraph, path_nodes: list):
    """
    Find the cheapest edge NOT in the MST that connects a node from the
    first half of the path to a node in the second half — creating a
    shortcut / bypass.
    """
    half = len(path_nodes) // 2
    first_half  = set(path_nodes[:half + 1])
    second_half = set(path_nodes[half:])

    best_key  = None
    best_cost = float('inf')

    for key, edge in city.edges.items():
        if key in city.mst_edges:
            continue   # already in MST
        crosses = (edge.u in first_half and edge.v in second_half) or \
                  (edge.v in first_half and edge.u in second_half)
        if crosses and edge.base_cost < best_cost:
            best_cost = edge.base_cost
            best_key  = key

    return best_key


def mst_total_cost(city: CityGraph) -> float:
    """Total cost of all roads in the MST (for display in GUI)."""
    return round(sum(
        city.edges[k].base_cost for k in city.mst_edges if k in city.edges
    ), 2)
