"""
Challenge 1 — City Layout Planning
Algorithm: Constraint Satisfaction Problem (CSP) with Backtracking

The city is an empty 10×10 grid. We must assign building types to cells
while satisfying three hard rules:

  Rule A: Industrial zones cannot be ADJACENT to Hospitals or Schools.
  Rule B: Every Residential cell must be within 3 road hops of a Hospital.
  Rule C: Every Power Plant must be within 2 road hops of an Industrial zone.

Why CSP?
  We are assigning values (building types) to variables (grid positions) under
  constraints. Backtracking systematically tries every valid assignment and
  backtracks when a dead end is reached — exactly what CSP solvers do.
  Alternative considered: local search / min-conflicts, but backtracking gives
  a complete, provably correct solution for a grid this size.
"""

import random
import sys
sys.path.insert(0, '..')
from city_graph import CityGraph

# How many of each special building to place
BUILDING_COUNTS = {
    'H': 2,   # Hospitals
    'S': 3,   # Schools
    'I': 4,   # Industrial zones
    'P': 2,   # Power Plants
    'A': 2,   # Ambulance Depots
}
RESIDENTIAL_FILL = 0.45   # ~45 % of remaining cells become Residential


def solve_layout(city: CityGraph, seed: int = 42) -> dict:
    """
    Main entry point.  Fills the city graph with a valid layout and
    returns a dict of any constraint violations found afterwards.
    """
    random.seed(seed)
    n = city.rows
    all_pos = [(r, c) for r in range(n) for c in range(n)]
    random.shuffle(all_pos)

    # Build ordered list of buildings to place: [H, H, S, S, S, I, I, I, I, P, P, A, A]
    to_place = []
    for btype, count in BUILDING_COUNTS.items():
        to_place.extend([btype] * count)

    # CSP Backtracking ──────────────────────────────────────────────
    assignment: dict = {}           # pos -> type

    def backtrack(idx: int) -> bool:
        """
        Try to place to_place[idx] somewhere on the grid.
        If no position works, return False (trigger backtrack).
        """
        if idx == len(to_place):
            return True             # All buildings placed — success!

        btype = to_place[idx]

        for pos in all_pos:
            if pos in assignment:
                continue            # Cell already taken
            if _placement_ok(pos, btype, assignment, n):
                assignment[pos] = btype
                if backtrack(idx + 1):
                    return True
                del assignment[pos] # Backtrack: undo and try next position

        return False                # No valid position found at this level

    success = backtrack(0)

    if not success:
        # Fallback: greedy placement (satisfies Rule A; Rules B/C reported)
        _greedy_fallback(assignment, to_place, all_pos, n)

    # Apply special buildings to city
    for pos, btype in assignment.items():
        city.set_type(pos, btype)

    # Fill remaining cells — Residential only within 3 hops of a Hospital (Rule B)
    hosp_positions = [p for p, t in assignment.items() if t == 'H']
    within_3_hops  = _cells_within_hops(hosp_positions, 3, n)

    for pos in all_pos:
        if pos not in assignment:
            near_hosp = pos in within_3_hops
            if near_hosp and random.random() < RESIDENTIAL_FILL:
                city.set_type(pos, 'R')
            else:
                city.set_type(pos, 'E')

    # Assign realistic population densities
    _assign_populations(city)

    # Return any violations (Rule B and C need global BFS; check after fill)
    return check_constraints(city)


def _placement_ok(pos: tuple, btype: str, assignment: dict, n: int) -> bool:
    """
    Rule A: Industrial not adjacent to Hospital/School (and vice-versa).
    Rule C: Power Plant within 2 Manhattan hops of an Industrial zone.
    """
    nbrs = _grid_neighbors(pos, n)

    if btype == 'I':
        for nbr in nbrs:
            if assignment.get(nbr) in ('H', 'S'):
                return False

    if btype in ('H', 'S'):
        for nbr in nbrs:
            if assignment.get(nbr) == 'I':
                return False

    # Rule C enforced at placement time (industrial zones already placed before P)
    if btype == 'P':
        ind_positions = [p for p, t in assignment.items() if t == 'I']
        if ind_positions:
            min_dist = min(
                abs(pos[0]-ip[0]) + abs(pos[1]-ip[1]) for ip in ind_positions
            )
            if min_dist > 2:
                return False

    return True


def _cells_within_hops(sources: list, max_hops: int, n: int) -> set:
    """BFS on the grid (no edges needed) to find all cells within max_hops of any source."""
    from collections import deque
    result  = set(sources)
    queue   = deque([(s, 0) for s in sources])
    visited = set(sources)
    while queue:
        pos, d = queue.popleft()
        result.add(pos)
        if d < max_hops:
            for nbr in _grid_neighbors(pos, n):
                if nbr not in visited:
                    visited.add(nbr)
                    queue.append((nbr, d + 1))
    return result


def _grid_neighbors(pos: tuple, n: int) -> list:
    """Four-directional grid neighbours within bounds."""
    r, c = pos
    result = []
    for dr, dc in [(-1,0),(1,0),(0,-1),(0,1)]:
        nr, nc = r + dr, c + dc
        if 0 <= nr < n and 0 <= nc < n:
            result.append((nr, nc))
    return result


def _greedy_fallback(assignment: dict, to_place: list, all_pos: list, n: int):
    """Called only when backtracking finds no solution (very rare for this grid).
    Places buildings greedily, satisfying Rule A where possible."""
    placed_types = []
    for btype in to_place:
        for pos in all_pos:
            if pos not in assignment and _placement_ok(pos, btype, assignment, n):
                assignment[pos] = btype
                placed_types.append(btype)
                break
        else:
            # Last resort: place ignoring adjacency constraints
            for pos in all_pos:
                if pos not in assignment:
                    assignment[pos] = btype
                    break


def _assign_populations(city: CityGraph):
    """Give each node a realistic population density."""
    pop_map = {
        'R': (800, 2000),
        'H': (100, 300),
        'S': (200, 500),
        'I': (50, 200),
        'P': (10, 50),
        'A': (20, 80),
        'E': (0, 30),
    }
    for node in city.nodes.values():
        lo, hi = pop_map.get(node.node_type, (0, 100))
        node.population = random.randint(lo, hi)


# ── Constraint Checker (post-placement global rules) ───────────────────

def check_constraints(city: CityGraph) -> dict:
    """
    Verify all three CSP rules after layout is complete.
    Returns a dict: {rule_name: [violation_strings]}.
    An empty dict means the layout is fully valid.
    """
    violations = {}
    n = city.rows

    # Rule A: Industrial not adjacent to Hospital / School
    rule_a = []
    for pos, node in city.nodes.items():
        if node.node_type == 'I':
            for nbr in _grid_neighbors(pos, n):
                ntype = city.nodes[nbr].node_type
                if ntype in ('H', 'S'):
                    rule_a.append(f"Industrial {pos} adj to {ntype} {nbr}")
    if rule_a:
        violations['Rule A – Industrial adjacency'] = rule_a

    # Rule B: Every Residential within 3 hops of a Hospital
    hospitals = set(city.get_by_type('H'))
    rule_b = []
    for pos, node in city.nodes.items():
        if node.node_type == 'R':
            dist = _bfs_min_dist(city, pos, hospitals)
            if dist > 3:
                rule_b.append(f"Residential {pos} is {dist} hops from nearest hospital")
    if rule_b:
        violations['Rule B – Residential↔Hospital distance'] = rule_b

    # Rule C: Every Power Plant within 2 hops of an Industrial zone
    industrials = set(city.get_by_type('I'))
    rule_c = []
    for pos, node in city.nodes.items():
        if node.node_type == 'P':
            dist = _bfs_min_dist(city, pos, industrials)
            if dist > 2:
                rule_c.append(f"Power Plant {pos} is {dist} hops from nearest industrial")
    if rule_c:
        violations['Rule C – PowerPlant↔Industrial distance'] = rule_c

    return violations


def _bfs_min_dist(city: CityGraph, start: tuple, targets: set) -> int:
    """BFS hop-distance from start to the nearest target (ignores road blocks)."""
    if start in targets:
        return 0
    from collections import deque
    visited = {start}
    queue = deque([(start, 0)])
    while queue:
        pos, d = queue.popleft()
        for nbr, _ in city.neighbors(pos, only_open=False):
            if nbr in targets:
                return d + 1
            if nbr not in visited:
                visited.add(nbr)
                queue.append((nbr, d + 1))
    return float('inf')
