# algorithms package — five AI challenge modules for CityMind
