"""
Challenge 4 — Emergency Routing Under Changing Conditions
Algorithm: A* Search with dynamic re-routing

A medical team must visit a list of trapped civilians. Roads may flood
mid-journey. When a road is blocked, the route is immediately recalculated.

Why A*?
  We need the SHORTEST available path (not just any path). A* is guaranteed
  to find the optimal path as long as its heuristic is admissible — never
  overestimates the true cost. Manhattan distance on a grid is admissible:
  it counts the minimum possible steps ignoring obstacles.

  BFS was also considered. BFS finds the path with fewest hops but cannot
  handle weighted edges (residential roads cost 0.8; risk zones add a
  multiplier). A* handles weights correctly via g(n), while the heuristic
  h(n) guides the search toward the goal.

  Dynamic re-routing: when a road is blocked we simply re-call A* from
  the team's CURRENT position. No specialised algorithm is needed because
  A* always works on the current graph state.

Multi-civilian routing:
  Greedy nearest-neighbour — always visit the closest unvisited civilian
  first. This is a simple approximation of the Travelling Salesman Problem.
  Optimal TSP is NP-hard; greedy gives good results for the small number
  of civilians in this simulation.
"""

import heapq
import sys
sys.path.insert(0, '..')
from city_graph import CityGraph


def astar(city: CityGraph, start: tuple, goal: tuple) -> list:
    """
    A* search from start to goal on the city graph.

    Returns the shortest path as a list of positions [start, ..., goal],
    or an empty list if the goal is unreachable.

    How it works:
      f(n) = g(n) + h(n)
        g(n) = actual cost paid so far to reach n
        h(n) = Manhattan distance from n to goal  (admissible heuristic)
      We always expand the node with the lowest f — this guarantees optimality.
    """
    if start == goal:
        return [start]

    # Min-heap: (f_cost, g_cost, position)
    open_heap = []
    heapq.heappush(open_heap, (0.0, 0.0, start))

    g_cost   = {start: 0.0}   # cheapest known cost to each node
    came_from = {}             # parent pointer for path reconstruction

    while open_heap:
        f, g, current = heapq.heappop(open_heap)

        if current == goal:
            return _reconstruct(came_from, current)

        # If we already processed this node with a lower cost, skip
        if g > g_cost.get(current, float('inf')):
            continue

        for neighbor, edge_cost in city.neighbors(current, only_open=True):
            # High-risk areas act as a cost multiplier (Challenge 5 integration)
            risk_mul = 1.0 + city.nodes[neighbor].risk_index * 0.5
            new_g = g_cost[current] + edge_cost * risk_mul

            if new_g < g_cost.get(neighbor, float('inf')):
                g_cost[neighbor] = new_g
                h = city.manhattan(neighbor, goal)  # heuristic
                heapq.heappush(open_heap, (new_g + h, new_g, neighbor))
                came_from[neighbor] = current

    return []  # goal unreachable


def _reconstruct(came_from: dict, current: tuple) -> list:
    """Follow parent pointers back from goal to start, then reverse."""
    path = [current]
    while current in came_from:
        current = came_from[current]
        path.append(current)
    path.reverse()
    return path


def route_to_civilians(city: CityGraph, start: tuple, civilians: list) -> tuple:
    """
    Plan a complete route from start visiting all civilians.

    Strategy: greedy nearest-neighbour.
    At each step, go to the closest unvisited civilian (by A* cost).

    Returns (full_path_as_node_list, total_cost).
    """
    if not civilians:
        return [start], 0.0

    remaining = list(civilians)
    current   = start
    full_path = [start]
    total_cost = 0.0

    while remaining:
        # Find the cheapest (nearest) reachable civilian
        best_target = None
        best_path   = None
        best_cost   = float('inf')

        for target in remaining:
            path = astar(city, current, target)
            if not path:
                continue
            cost = _path_cost(city, path)
            if cost < best_cost:
                best_cost   = cost
                best_target = target
                best_path   = path

        if best_target is None:
            break  # remaining civilians are unreachable

        # Extend route (skip first node — it equals current position)
        full_path.extend(best_path[1:])
        total_cost += best_cost
        current = best_target
        remaining.remove(best_target)

    return full_path, total_cost


def recalculate_route(city: CityGraph, current_pos: tuple,
                      remaining_civilians: list) -> tuple:
    """
    Called the moment a road is blocked mid-journey.
    Immediately re-plans from current_pos using A* on the updated graph.
    Returns (new_path, new_cost).
    """
    return route_to_civilians(city, current_pos, remaining_civilians)


def _path_cost(city: CityGraph, path: list) -> float:
    """Sum the effective edge costs along a path."""
    cost = 0.0
    for i in range(len(path) - 1):
        u, v = path[i], path[i + 1]
        key  = (min(u, v), max(u, v))
        edge = city.edges.get(key)
        if edge:
            cost += edge.effective_cost
    return cost
