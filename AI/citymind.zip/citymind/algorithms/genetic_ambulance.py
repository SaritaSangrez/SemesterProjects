"""
Challenge 3 — Ambulance Placement
Algorithm: Genetic Algorithm (GA)

Goal: Place 3 ambulances so that the WORST-CASE response time is minimised.
(The citizen furthest from any ambulance should be as close as possible.)

Why Genetic Algorithm?
  The search space is C(100, 3) = 161,700 possible placements.
  Brute force would check every one. GA instead maintains a population
  of candidate solutions and evolves them toward the optimum through
  selection, crossover, and mutation — typically converging in far fewer
  evaluations. This mirrors how biological evolution finds good solutions
  in a huge search space without examining every possibility.
  Alternative considered: Simulated Annealing (single solution, random
  walk with cooling). GA was chosen because it explores multiple regions
  simultaneously, reducing the risk of getting stuck in local optima.
"""

import random
from city_graph import CityGraph


NUM_AMBULANCES  = 3
POPULATION_SIZE = 50
GENERATIONS     = 100
MUTATION_RATE   = 0.25
ELITE_KEEP      = 6     # top individuals carried unchanged to next generation


def place_ambulances(city: CityGraph, seed: int = 0) -> list:
    """
    Run the Genetic Algorithm and return the best 3 ambulance positions.
    Updates city.ambulance_positions.
    """
    random.seed(seed)
    nodes = list(city.nodes.keys())

    # Pre-compute all BFS distances once (100 BFS runs, each O(V+E))
    # This avoids repeating BFS inside the hot fitness loop.
    dist_cache = _build_dist_matrix(city, nodes)

    # ── Initial population ──────────────────────────────────────────
    # Each individual = list of 3 positions (a candidate placement)
    population = [
        random.sample(nodes, NUM_AMBULANCES) for _ in range(POPULATION_SIZE)
    ]

    best = min(population, key=lambda p: _fitness(p, nodes, dist_cache))

    # ── Evolution loop ──────────────────────────────────────────────
    for gen in range(GENERATIONS):
        # Sort best-first (lowest fitness score = best coverage)
        population.sort(key=lambda p: _fitness(p, nodes, dist_cache))

        # Track global best
        if _fitness(population[0], nodes, dist_cache) < _fitness(best, nodes, dist_cache):
            best = population[0][:]

        # Build next generation
        next_gen = [ind[:] for ind in population[:ELITE_KEEP]]  # elitism

        while len(next_gen) < POPULATION_SIZE:
            p1 = _tournament_select(population, nodes, dist_cache)
            p2 = _tournament_select(population, nodes, dist_cache)
            child = _crossover(p1, p2, nodes)
            child = _mutate(child, nodes)
            next_gen.append(child)

        population = next_gen

    # Ensure positions are tuples (not lists) for consistent dict keys
    best = [tuple(p) for p in best]
    city.ambulance_positions = best
    return best


# ── Fitness ─────────────────────────────────────────────────────────────

def _fitness(placement: list, all_nodes: list, dist_cache: dict) -> float:
    """
    Fitness = the maximum distance from any node to its nearest ambulance.
    Lower is better (we want to minimise worst-case response time).
    """
    worst = 0
    for node in all_nodes:
        # Distance to nearest ambulance
        nearest = min(dist_cache.get((node, tuple(amb)), 9999) for amb in placement)
        if nearest > worst:
            worst = nearest
    return worst


# ── Selection ────────────────────────────────────────────────────────────

def _tournament_select(population: list, nodes: list, dist_cache: dict) -> list:
    """
    Tournament selection: pick 3 random individuals, return the best one.
    Gives fitter individuals a higher chance without completely excluding weaker ones.
    """
    contestants = random.sample(population, min(3, len(population)))
    return min(contestants, key=lambda p: _fitness(p, nodes, dist_cache))


# ── Crossover ────────────────────────────────────────────────────────────

def _crossover(parent1: list, parent2: list, all_nodes: list) -> list:
    """
    Combine two placements: union their positions, then pick 3 from the pool.
    If they share positions the child inherits them (likely good genes).
    """
    pool = list({tuple(p) for p in parent1} | {tuple(p) for p in parent2})
    random.shuffle(pool)
    child = list(pool[:NUM_AMBULANCES])   # keep as tuples

    # Pad if both parents were identical
    while len(child) < NUM_AMBULANCES:
        child.append(random.choice(all_nodes))

    return child


# ── Mutation ─────────────────────────────────────────────────────────────

def _mutate(placement: list, all_nodes: list) -> list:
    """
    With MUTATION_RATE probability, replace one ambulance position randomly.
    Mutation prevents the population from converging too early (diversity).
    """
    if random.random() < MUTATION_RATE:
        placement = placement[:]
        idx = random.randint(0, NUM_AMBULANCES - 1)
        placement[idx] = random.choice(all_nodes)
    return placement


# ── Distance pre-computation ──────────────────────────────────────────────

def _build_dist_matrix(city: CityGraph, nodes: list) -> dict:
    """
    BFS from every node to every other node.
    Returns {(start, end): hop_count} for all pairs.
    Called once before the GA loop for efficiency.
    """
    dist = {}
    for start in nodes:
        bfs_result = city.bfs_distances(start, only_open=True)
        for end in nodes:
            dist[(start, tuple(end))] = bfs_result.get(end, 9999)
            dist[(tuple(end), start)] = dist[(start, tuple(end))]
    return dist


def compute_coverage_zones(city: CityGraph) -> dict:
    """
    For each node, determine which ambulance covers it (nearest ambulance index).
    Returns {pos: zone_index (0, 1, or 2)}.
    Used by the GUI to draw the Ambulance Coverage overlay.
    """
    if not city.ambulance_positions:
        return {}

    zones = {}
    for pos in city.nodes:
        best_idx = 0
        best_dist = float('inf')
        for i, amb in enumerate(city.ambulance_positions):
            d = city.manhattan(pos, amb)
            if d < best_dist:
                best_dist = d
                best_idx = i
        zones[pos] = best_idx
    return zones
