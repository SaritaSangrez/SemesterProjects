"""
city_graph.py  —  Shared City Graph (Single Source of Truth)

Every module in CityMind reads and writes through this one object.
A road block, risk update, or building placement is instantly
visible to all other modules — no separate copies allowed.
"""

from typing import Dict, List, Tuple, Callable


# ── Building types ─────────────────────────────────────────────────────
TYPES = {
    'R': 'Residential',
    'H': 'Hospital',
    'S': 'School',
    'I': 'Industrial',
    'P': 'Power Plant',
    'A': 'Amb. Depot',
    'E': 'Empty',
}

# Wireframe colour palette
COLORS = {
    'R': '#a8c8f0',   # blue
    'H': '#f4b8b8',   # red / pink
    'S': '#9de0b0',   # green
    'I': '#f5d990',   # yellow
    'P': '#d8b4fe',   # purple
    'A': '#fba94c',   # orange
    'E': '#d8d4cc',   # warm gray
}

RISK_COLORS = {
    'High':   '#fca5a5',
    'Medium': '#fdba74',
    'Low':    '#86efac',
}

# Three distinct colours for ambulance Voronoi zones
AMB_ZONE_COLORS = ['#bfdbfe', '#bbf7d0', '#fde68a']


class Node:
    """A single location in the city grid."""

    def __init__(self, row: int, col: int):
        self.row = row
        self.col = col
        self.node_type: str = 'E'      # key from TYPES
        self.population: int = 0
        self.risk_index: float = 0.0   # 0–1, set by crime module
        self.risk_level: str = 'Low'   # 'High' | 'Medium' | 'Low'
        self.accessible: bool = True

    @property
    def pos(self) -> Tuple[int, int]:
        return (self.row, self.col)


class Edge:
    """A road segment between two adjacent locations."""

    def __init__(self, u: Tuple, v: Tuple, cost: float = 1.0):
        self.u = u
        self.v = v
        self.base_cost = cost   # 1.0 standard, 0.8 through residential
        self.blocked = False    # True when flooded / destroyed

    @property
    def effective_cost(self) -> float:
        return float('inf') if self.blocked else self.base_cost

    @property
    def key(self) -> Tuple:
        """Canonical (ordered) key for dict lookup."""
        return (min(self.u, self.v), max(self.u, self.v))


class CityGraph:
    """
    The shared city graph — one object, one truth.

    All five challenge modules operate on this same instance.
    Any mutation (block road, set risk, place building) is
    immediately visible everywhere via the observer callbacks.
    """

    def __init__(self, rows: int = 10, cols: int = 10):
        self.rows = rows
        self.cols = cols
        self.nodes:  Dict[Tuple, Node] = {}
        self.edges:  Dict[Tuple, Edge] = {}
        self.mst_edges: set = set()                # built by Challenge 2
        self.ambulance_positions: List[Tuple] = [] # set by Challenge 3
        self._callbacks: List[Callable] = []
        self._build_grid()

    # ── Construction ───────────────────────────────────────────────────

    def _build_grid(self):
        """Create all nodes and connect them with 4-directional edges."""
        for r in range(self.rows):
            for c in range(self.cols):
                self.nodes[(r, c)] = Node(r, c)
        for r in range(self.rows):
            for c in range(self.cols):
                if c + 1 < self.cols:
                    self._add_edge((r, c), (r, c + 1))
                if r + 1 < self.rows:
                    self._add_edge((r, c), (r + 1, c))

    def _add_edge(self, u: Tuple, v: Tuple, cost: float = 1.0):
        key = (min(u, v), max(u, v))
        self.edges[key] = Edge(u, v, cost)

    # ── Node mutations ──────────────────────────────────────────────────

    def set_type(self, pos: Tuple, node_type: str):
        """Place a building type and update adjacent road costs."""
        self.nodes[pos].node_type = node_type
        self._refresh_edge_costs(pos)
        self._notify()

    def _refresh_edge_costs(self, pos: Tuple):
        """Roads touching a Residential cell cost 0.8 instead of 1.0."""
        for edge in self.edges.values():
            if pos in (edge.u, edge.v):
                u_res = self.nodes[edge.u].node_type == 'R'
                v_res = self.nodes[edge.v].node_type == 'R'
                edge.base_cost = 0.8 if (u_res or v_res) else 1.0

    def set_risk(self, pos: Tuple, level: str, index: float):
        """Update risk level — called by the crime prediction module."""
        self.nodes[pos].risk_level = level
        self.nodes[pos].risk_index = index

    # ── Road mutations ──────────────────────────────────────────────────

    def block_road(self, u: Tuple, v: Tuple) -> bool:
        """Block a road (flood / accident). Returns True on success."""
        key = (min(u, v), max(u, v))
        if key in self.edges and not self.edges[key].blocked:
            self.edges[key].blocked = True
            self._notify()
            return True
        return False

    def unblock_road(self, u: Tuple, v: Tuple) -> bool:
        """Re-open a previously blocked road."""
        key = (min(u, v), max(u, v))
        if key in self.edges and self.edges[key].blocked:
            self.edges[key].blocked = False
            self._notify()
            return True
        return False

    # ── Graph queries ───────────────────────────────────────────────────

    def neighbors(self, pos: Tuple, only_open: bool = True) -> List[Tuple]:
        """
        Return [(neighbor_pos, cost)] for all adjacent cells.
        Pass only_open=False to include blocked roads (e.g. for BFS that
        needs to count hops regardless of road state).
        """
        result = []
        for edge in self.edges.values():
            if edge.u == pos:
                nbr = edge.v
            elif edge.v == pos:
                nbr = edge.u
            else:
                continue
            if only_open and edge.blocked:
                continue
            result.append((nbr, edge.effective_cost))
        return result

    def get_by_type(self, node_type: str) -> List[Tuple]:
        """All positions that have the given building type."""
        return [p for p, n in self.nodes.items() if n.node_type == node_type]

    def manhattan(self, a: Tuple, b: Tuple) -> float:
        """Manhattan distance — admissible heuristic for A*."""
        return abs(a[0] - b[0]) + abs(a[1] - b[1])

    def bfs_distances(self, start: Tuple, only_open: bool = True) -> Dict[Tuple, int]:
        """
        BFS from start. Returns {pos: hop_count} for every reachable node.
        Runs in O(V + E) where V=100 nodes, E=180 edges.
        """
        from collections import deque
        dist = {start: 0}
        queue = deque([start])
        while queue:
            pos = queue.popleft()
            for nbr, _ in self.neighbors(pos, only_open=only_open):
                if nbr not in dist:
                    dist[nbr] = dist[pos] + 1
                    queue.append(nbr)
        return dist

    def count_blocked(self) -> int:
        return sum(1 for e in self.edges.values() if e.blocked)

    # ── Observer pattern ────────────────────────────────────────────────

    def subscribe(self, callback: Callable):
        """GUI widgets subscribe here to be notified of any change."""
        self._callbacks.append(callback)

    def notify(self):
        """Manually trigger a notification (useful after bulk set_risk calls)."""
        self._notify()

    def _notify(self):
        for cb in self._callbacks:
            try:
                cb()
            except Exception:
                pass
