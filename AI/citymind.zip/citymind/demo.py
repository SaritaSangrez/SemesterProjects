"""
demo.py  —  Terminal demo of all five CityMind algorithms

Run:  python demo.py
Demonstrates every challenge without launching the GUI.
Useful for tracing algorithm behaviour step-by-step.
"""
import sys, os
sys.path.insert(0, os.path.dirname(__file__))

from city_graph import CityGraph, TYPES
from algorithms.csp_layout       import solve_layout, check_constraints
from algorithms.mst_roads         import build_road_network, mst_total_cost
from algorithms.genetic_ambulance import place_ambulances
from algorithms.astar_routing     import astar, route_to_civilians
from algorithms.crime_prediction  import run_crime_prediction


def separator(title):
    print(f"\n{'─'*60}")
    print(f"  {title}")
    print('─'*60)


def main():
    print("\n" + "="*60)
    print("  CityMind — Urban Intelligence System  (Terminal Demo)")
    print("="*60)

    city = CityGraph(rows=10, cols=10)

    # ─────────────────────────────────────────────────────────────
    separator("Challenge 1: City Layout Planning  (CSP Backtracking)")
    # ─────────────────────────────────────────────────────────────
    violations = solve_layout(city, seed=42)

    # Count building types
    counts = {}
    for node in city.nodes.values():
        counts[node.node_type] = counts.get(node.node_type, 0) + 1

    print("Building placement:")
    for code, label in TYPES.items():
        print(f"  {label:18s}: {counts.get(code, 0):3d} cells")

    if not violations:
        print("\n✓ All CSP constraints satisfied.")
    else:
        for rule, items in violations.items():
            print(f"\n⚠  {rule}: {len(items)} violation(s)")
            for item in items[:3]:
                print(f"     {item}")

    # Print a tiny ASCII map of the layout
    print("\nGrid layout (top-left corner 5×5):")
    for r in range(5):
        row_str = '  '
        for c in range(5):
            row_str += city.nodes[(r,c)].node_type + ' '
        print(row_str)

    # ─────────────────────────────────────────────────────────────
    separator("Challenge 2: Road Network Optimization  (Kruskal's MST)")
    # ─────────────────────────────────────────────────────────────
    n_roads = build_road_network(city)
    cost    = mst_total_cost(city)
    print(f"MST size   : {n_roads} roads selected (from 180 possible)")
    print(f"Total cost : {cost}")
    print(f"Min needed : {city.rows * city.cols - 1} (spanning tree needs n-1 edges)")
    print(f"Extra roads: {n_roads - (city.rows*city.cols - 1)} (for Hospital↔Depot redundancy)")

    # ─────────────────────────────────────────────────────────────
    separator("Challenge 5: Crime Prediction  (K-Means + Decision Tree)")
    # ─────────────────────────────────────────────────────────────
    predictions = run_crime_prediction(city, seed=7)
    high   = sum(1 for v in predictions.values() if v == 'High')
    medium = sum(1 for v in predictions.values() if v == 'Medium')
    low    = sum(1 for v in predictions.values() if v == 'Low')
    print(f"Predictions: {high} High · {medium} Medium · {low} Low")
    print("\nSample predictions (first 8 cells):")
    for i, (pos, level) in enumerate(list(predictions.items())[:8]):
        node = city.nodes[pos]
        print(f"  {pos} [{node.node_type}] pop={node.population:4d} → {level:6s} "
              f"(risk_index={node.risk_index:.2f})")

    # ─────────────────────────────────────────────────────────────
    separator("Challenge 3: Ambulance Placement  (Genetic Algorithm)")
    # ─────────────────────────────────────────────────────────────
    positions = place_ambulances(city, seed=0)
    print(f"Optimal ambulance positions: {positions}")

    # Compute worst-case coverage distance
    max_dist = 0
    for pos in city.nodes:
        nearest = min(city.manhattan(pos, amb) for amb in positions)
        if nearest > max_dist:
            max_dist = nearest
            worst_node = pos
    print(f"Worst-case distance: {max_dist} hops (node {worst_node})")
    print(f"Population sizes, GA parameters: {50} individuals, {100} generations")

    # ─────────────────────────────────────────────────────────────
    separator("Challenge 4: Emergency Routing  (A* Search)")
    # ─────────────────────────────────────────────────────────────
    import random; random.seed(123)
    hospitals   = city.get_by_type('H')
    residentials= city.get_by_type('R')
    team_start  = hospitals[0] if hospitals else (0, 0)
    civilians   = random.sample(residentials, min(5, len(residentials)))

    print(f"Team start  : {team_start}")
    print(f"Civilians   : {civilians}")

    full_path, total_cost = route_to_civilians(city, team_start, civilians)
    print(f"Route length: {len(full_path)} steps, total cost {total_cost:.2f}")
    print(f"Path preview: {full_path[:8]}{'...' if len(full_path)>8 else ''}")

    # Demo: block one road and recalculate
    if len(full_path) > 3:
        u, v = full_path[1], full_path[2]
        city.block_road(u, v)
        print(f"\nSimulating road block: {u}→{v} flooded!")
        new_path, new_cost = route_to_civilians(city, team_start, civilians)
        if new_path:
            print(f"A* recalculated: {len(new_path)} steps, cost {new_cost:.2f}")
        else:
            print("WARNING: No available path after road block!")

    # ─────────────────────────────────────────────────────────────
    print(f"\n{'='*60}")
    print("  Demo complete. Launch the GUI:  python main.py")
    print('='*60 + '\n')


if __name__ == '__main__':
    main()
