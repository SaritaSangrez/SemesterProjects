 #include <iostream>
#include<fstream>
#include "stocks.h"
#include <cstring>
#include<cstdlib>
#include<cstdio>
#include <string>

using namespace std;

	static int prev_quantities[10];
	

	void removeLineFromFile(const char* filename, const string& lineToRemove) {
		ifstream inputFile(filename);
		ofstream outputFile("temp.txt");

		if (!inputFile.is_open()) {
			return;
		}

		if (!outputFile.is_open()) {
			return;
		}

		string line;

		// Read each line from the input file
		while (getline(inputFile, line)) {
			// Check if the line matches the one to be removed
			if (line == lineToRemove) {
				continue; // Skip the line to be removed
			}

			// Write the line to the output file
			outputFile << line << "\n";
		}

		inputFile.close();
		outputFile.close();

		remove(filename);
		rename("temp.txt", filename);
	}
	//store data
	void store_data()
	{
		int num_items = 10;
		
		items = new char*[num_items];
		for ( int i = 0; i < num_items; i++) {
		items[i] = new char[50];
		}
		fstream file;
		file.open("itemnames.txt", ios::in);
		if (!file)
		{
			cout << "There seems to be an error placing order.Please try again later." << endl;	
		}
		
		quantity = new int[num_items];
		prices = new int[num_items];
		total_prices = new int[num_items];
		fstream Qfile("quantity.txt", ios::in);
		int i = 0;
		// storing the quantities in the array
		while(Qfile >> quantity[i]) {
			i++;
		}
		
		i = 0;
		
		// storing the prices in the array
		fstream Pfile("prices.txt", ios::in);
		while(Pfile >> prices[i]) {
		i++;
		}
		
		
		fstream TPfile("totalprices.txt", ios::in);
		while(TPfile >> prices[i]) {
		i++;
		}
		file.close();
		Qfile.close();
		Pfile.close();
		TPfile.close();	

	}
		

	void update_quantities(int* quantity)
	{	
		int num_items = 10;
		ofstream temp;
		temp.open("temp.txt");
		
    		if (!temp) {
        		cout << "Unable to process at the moment..." << endl;
        	return;
    		}
		
		for (int i = 0; i < num_items; ++i)
		{
    			temp << quantity[i] << "\n";
    		}
    		temp.close();
    		remove("quantity.txt");
    		rename("temp.txt","quantity.txt");
	}

	void update_prev_quantities(int* quantity, int* prev_quantities, int num_items) 
	{
   	 	for (int i = 0; i < num_items; ++i) {
        	prev_quantities[i] = quantity[i];
    		}
	}
	void salesCalc() 
	{
		int num_items = 10;
		store_data();
		update_prev_quantities(quantity,prev_quantities,num_items);
		update_quantities(quantity);
		int total_quantity = 0, total_sales = 1;
		double total_price = 0;
		for ( int i = 0; i < num_items; i++) {
			total_quantity += quantity[i];
			total_price += quantity[i]*prices[i];
			total_sales += prev_quantities[i] - quantity[i];
		}
		double avg_quantity = (double) total_quantity / num_items;
		double avg_price = total_price / total_quantity;
		cout << "Average Quantity = Rs."<< avg_quantity << endl;
		cout << "Average Price = Rs."<< avg_price << endl;
		cout << "Total Sales of the day = "<< total_sales << endl;
	}
		
	//to search item through file
	bool search(const char* filename, const char* item)
	{
		fstream file(filename);
		if (!file) {
			cout << "Unable to process at the moment." << endl;
			return false;
		}
		
		const int max_line = 1024;
		char line [max_line];
		while (file.getline(line, max_line)) {
		if (strstr(line, item) != NULL) {
		return true;
			}
	 	}
	 	return false;
	}
	 	
	 	
	 //to schedule order
	 void schedOrder()
	 {
	 		string order;
	 		fstream orderFile;
	 		orderFile.open("schedOrders.txt", ios::app);
	 		if (!orderFile) {
			cout << "Unable to process at the moment...\n";
			return;
			}
			cout << "Please enter your order : ";
			cin.ignore();
			getline(cin, order);
		
			orderFile << order << endl;
			cout << "Your order has been received : " << order << endl;
	 	
	}
	 			
	 //to view scheduled orders
	 void seeOrder() 
	 {
	 	fstream orderFile;
	 	orderFile.open("schedOrders.txt", ios::in);
	 	if (!orderFile) {
			cout << "Unable to process at the moment...\n";
			return;
		}
		string order;
		while (getline(orderFile, order)) {
			cout << "Order : " << order << endl << endl;
			}
		orderFile.close();
	
	 }
	 	
	//function to make complaint
	void Makecomplaint() 
	{
		fstream fileComp;
		fileComp.open ( "complaints.txt", ios::app);
		string complaint;
	    	char response;

	   	cout << "Do you want to make a complaint? (Y/N) or (y/n) : ";
	    	cin >> response;
	    	cin.ignore();  // Ignore the newline character in the input 

	    	if (response == 'Y' || response == 'y') {
		cout << "Please enter your complaint: ";
		getline(cin, complaint);
		
		fileComp << complaint << endl;
		cout << "Your complaint has been received : " << complaint << endl;
	    	}
	     	else if (response == 'N' || response == 'n'){
		cout << "No complaint made." << endl;
	    	}
	    	else cout << "Invalid input\n.";
	    	cout << "\n\n";
	    	
	    	fileComp.close();
	}
	
	//func to see complaint
	void seeComplaint()
	{
		fstream fileComp;
		fileComp.open ("complaints.txt", ios::in);
	 	if (!fileComp) {
			cout << "Unable to process at the moment...\n";
			return;
		}
		string complaint;
		while(getline(fileComp, complaint)) {
			cout << "Complaint Made : " << complaint << endl << endl;
			}
		fileComp.close();
	} 
		
	

	void respondComplaint() 
	 {
    	 	string responseComp;
    		cout << "Enter your response to the complaint: ";
    		cin.ignore();
    		getline(cin, responseComp);

    		fstream responseCompFile;
    		responseCompFile.open("compResponses.txt", ios::app);
		
    		if (!responseCompFile) {
        		cout << "Unable to process at the moment..." << endl;
        	return;
    		}

    		responseCompFile << responseComp << "\n";
    		responseCompFile.close();

    		cout << "Response recorded successfully!" << endl << endl;
    	}
    		
    	void displayNotif()
    	{
    		string notif;
    		cout << "NOTIFICATION : ";
    		cin.ignore();
    		getline(cin, notif);
    		
    		fstream displayNotifFile;
    		displayNotifFile.open("DisplayNotif.txt", ios::app);
    		
    		if (!displayNotifFile) {
    			cout << "Unable to process at the moment..." << endl;
    		return;
    		}
    		
    		displayNotifFile << notif << "\n";
    		displayNotifFile.close();
    		cout << "Notification displayed successfully!\n";
    	}
    	
    	
 
 	//to see notification
	void seeNotif() 
	{
		fstream displayNotifFile;
		displayNotifFile.open("DisplayNotif.txt", ios::in);
	 	if (!displayNotifFile) {
			cout << "Unable to process at the moment...\n";
			return;
		}
		string notif;
		while(getline(displayNotifFile, notif)) {
			cout << "NOTIFICATION : " << notif << endl << endl;
			}
		displayNotifFile.close();
	} 

	void ReStock(char** items, int* prices, int* quantity, int choice)
	{
		string line;
		int no_item;       //no. of item the user wants
		int num_items = 10;     //10 number of items
		int max_item_length = 256;
		
		char item[50];
		store_data();
		cout <<"\n\n";
		cout << "CATEGORIES\n\n";
		cout << "Enter (1-3)\n";
		cout << "1. Savoury Foods\n";
		cout << "2. Sweet Foods\n";
		cout << "3. Beverages\n";
		cin >> choice;
		
		switch (choice) {
		case 1:                    //savoury 
		{
		cout << "__________________________________________________\n";
		cout << "|         Items          |          Quantity     |\n";
		cout << "--------------------------------------------------\n";
		cout << "|      1.Biryani         |           " << quantity[0] << "          |\n";
		cout << "|      2.Fries           |           " << quantity[1] << "          |\n";
		cout << "|      3.Roll Paratha    |           " << quantity[2] << "          |\n";
		cout << "|      4.Pizza Slice     |           " << quantity[3] << "          |\n";
		cout << "|________________________________________________|\n";
		
		fstream file;
		file.open("itemnames.txt", ios::in);
		if (!file)
		{
			cout << "There seems to be an error placing order.Please try again later." << endl;	
		break;
		}
		
	 	cout << "Please enter the item you wish to restock (1-4) : ";
	 	
		cin.ignore();
		int index;
		cin >> index;
		if ( index <= 0 || index > 4) {
	 	cout << "Invalid input.Please try again.\n";
	 	return;
	 	}

			cout << "What quantity of the item do you want to order ? ";
			cin >> no_item;
			cout << endl;
			cout << endl;
									
			int temp = index;
			cout << "Item has been restocked successfully!\n" << endl << endl;
				quantity[index - 1] += no_item;
				update_quantities(quantity);
		
		
		file.close();
		    //case1
		}
		break;
		
		
		case 2:                    //sweet
		{
		cout << "___________________________________________________\n";
		cout << "|         Items          |          Quantity      |\n";
		cout << "---------------------------------------------------\n";
		cout << "|      1.Brownie         |              " << quantity[4] << "        |\n";
		cout << "|      2.Biscuis         |              " << quantity[5] << "        |\n";
		cout << "|      3.Plain cake      |              " << quantity[6] << "        |\n";
		cout << "|_________________________________________________|\n";

		fstream file; 
		file.open("itemnames.txt", ios::in);
		if (!file)
		{
			cout << "There seems to be an error placing order.Please try again later." << endl;	
		break;
		}
		
	 	cout << "Please enter the item you wish to restock (1-3) : ";
	 	
		cin.ignore();
		int index;
		cin >> index;
		if ( index <= 0 || index > 3) {
	 	cout << "Invalid input.Please try again\n";
	 	return;
	 	}
		index += 4;
			cout << "What quantity of the item do you want to order ? ";
			cin >> no_item;
			cout << endl;
			cout << endl;
									
			int temp = index;
			cout << "Item has been restocked successfully!\n" << endl << endl;
				quantity[index - 1] += no_item;
				update_quantities(quantity);
		
		file.close();
		}
		  //case2
		break;
		
		case 3:                    //Beverages
		
		cout << "___________________________________________________\n";
		cout << "|         Items          |          Quantity      |\n";
		cout << "---------------------------------------------------\n";
		cout << "|      1.Fresh Juice     |             " << quantity[7] << "         |\n";
		cout << "|      2.Soft Drinks     |             " << quantity[8] << "         |\n";
		cout << "|      3.Water           |             " << quantity[9] << "         |\n";
		cout << "|_________________________________________________|\n";
		
		fstream file;
		file.open("itemnames.txt", ios::in);
		if (!file)
		{
			cout << "There seems to be an error placing order.Please try again later." << endl;	
		break;
		}
		
	 	cout << "Please enter the item you want to order (1-3) : ";
	 	
		cin.ignore();
		int index;
		cin >> index;
		if ( index <= 0 || index > 3) {
	 	cout << "Invalid input.Please try again.\n";
	 	return;
	 	}
		index += 7;
			cout << "What quantity of the item do you want to order ? ";
			cin >> no_item;
			cout << endl;
			cout << endl;
									
			int temp = index;
			cout << "Item has been restocked successfully!\n" << endl << endl;
				quantity[index - 1] += no_item;
				update_quantities(quantity);
	
		
		file.close();
		
		
		}     //case 3
		}    //switch
		

	void order(char** items, int* prices, int* quantity, int choice)
	{
		string line;
		int no_item;       //no. of item the user wants
		int num_items = 10;     //10 number of items
		int max_item_length = 256;
		
		char item[50];
		store_data();
		cout <<"\n\n";
		cout << "CATEGORIES\n\n";
		cout << "Enter (1-3)\n";
		cout << "1. Savoury Foods\n";
		cout << "2. Sweet Foods\n";
		cout << "3. Beverages\n";
		cin >> choice;
		
		switch (choice) {
		case 1:                    //savoury 
		{
		cout << "___________________________________________________\n";
		cout << "|         Items          |          Price         |\n";
		cout << "---------------------------------------------------\n";
		cout << "|      1.Biryani         |          Rs. 150       |\n";
		cout << "|      2.Fries           |          Rs. 100       |\n";
		cout << "|      3.Roll Paratha    |          Rs. 200       |\n";
		cout << "|      4.Pizza Slice     |          Rs. 250       |\n";
		cout << "|_________________________________________________|\n";
		
		fstream file;
		file.open("itemnames.txt", ios::in);
		if (!file)
		{
			cout << "There seems to be an error placing order.Please try again later." << endl;	
		break;
		}
		
	 	cout << "Please enter the item you want to order (1-4) : ";
		cin.ignore();
		int index;
		cin >> index;
		if( index < 1 || index > 4) {
			cout << "Invalid Option.\n" << endl;
		}
		
		else {
		
			cout << "What quantity of the item do you want ? ";
			cin >> no_item;
			cout << endl;
			cout << endl;
									
			int price = 0;
			int temp = index;
			switch(index) {
				case 1: 
					if( quantity[index - 1] < no_item) {
						cout << "We do not have the required quantity at the moment." << endl; 	
			}
			else { 
				cout << "Quantity is available!" << endl;
				price = prices[index - 1] * no_item;
				cout << "Your order has been placed successfully!\nYou have ordered " << no_item << " plates of biryani\n" << "Your total bill is Rs. " << price << endl << endl;
				quantity[index - 1] -= no_item;
				update_quantities(quantity);
			}
				break;
				case 2: 
					if( quantity[index - 1] < no_item){
						cout << "We do not have the required quantity at the moment." << endl; 	
			}
			else { 
				cout << "Quantity is available!" << endl;
				price = prices[index - 1] * no_item;
				cout << "Your order has been placed successfully!\nYou have ordered " << no_item << " plates of fries\n" << "Your total bill is Rs. " << price << endl << endl;
				quantity[index - 1] -= no_item;
				update_quantities(quantity);
			}
				break;
				case 3: 
					cout << "Quantity is available!" <<endl;
					if( quantity[index - 1] < no_item) {
						cout << "We do not have the required quantity at the moment." << endl; 	
			}
			else { 
				cout << "Quantity is available!" << endl;
				price = prices[index - 1] * no_item;
				cout << "Your order has been placed successfully!\nYou have ordered " << no_item << " plates of roll paratha\n" << "Your total bill is Rs. " << price << endl << endl;
				quantity[index - 1] -= no_item;
				update_quantities(quantity);
			}
				break;
				case 4: 
					if( quantity[index - 1] < no_item){
						cout << "We do not have the required quantity at the moment." << endl; 	
			}
			else { 
				cout << "Quantity is available!" << endl;
				price = prices[index - 1] * no_item;
				cout << "Your order has been placed successfully!\nYou have ordered " << no_item << " plates of pizza slice\n" << "Your total bill is Rs. " << price << endl << endl;
				quantity[index - 1] -= no_item;
				update_quantities(quantity);
			}
				break;
				default:
				cout << "Invalid input." << endl;
				break;	
		}
		
		}
		
		file.close();
		}    //case1
		
		break;
		
		
		case 2:                    //sweet
		{
		cout << "___________________________________________________\n";
		cout << "|         Items          |          Price         |\n";
		cout << "---------------------------------------------------\n";
		cout << "|      1.Brownie         |          Rs. 150       |\n";
		cout << "|      2.Biscuis         |          Rs. 50        |\n";
		cout << "|      3.Plain cake      |          Rs. 200       |\n";
		cout << "|_________________________________________________|\n";

		fstream file; 
		file.open("itemnames.txt", ios::in);
		if (!file)
		{
			cout << "There seems to be an error placing order.Please try again later." << endl;	
		break;
		}
		
	 	cout << "Please enter the item you want to order (1-3) : ";
		cin.ignore();
		int index;
		cin >> index;
		if( index < 1 || index > 3) {
			cout << "Invalid Option\n" << endl;
		}
		
		else {
			index = index + 4;
			cout << "What quantity of the item do you want ? ";
			cin >> no_item;
			cout << endl;
			cout << endl;
			
			fstream Qfile("quantity.txt", ios::in);
			int i = 0;
		
			int price = 0;
			int temp = index;
			switch(index) {
				case 5: 
					if( quantity[index - 1] < no_item) {
						cout << "We do not have the required quantity at the moment." << endl; 	
			}
			else { 
				cout << "Quantity is available!" << endl;
				price = prices[index - 1] * no_item;
				cout << "Your order has been placed successfully!\nYou have ordered " << no_item << " plates of brownie\n" << "Your total bill is Rs. " << price << endl << endl;
				quantity[index - 1] -= no_item;
				update_quantities(quantity);
			}
				break;
				case 6: 
					if( quantity[index - 1] < no_item){
						cout << "We do not have the required quantity at the moment." << endl; 	
			}
			else { 
				cout << "Quantity is available!" << endl;
				price = prices[index - 1] * no_item;
				cout << "Your order has been placed successfully!\nYou have ordered " << no_item << " packs of biscuits\n" << "Your total bill is Rs. " << price << endl << endl;
				quantity[index - 1] -= no_item;
				update_quantities(quantity);
			}
				break;
				case 7: 
					cout << "Quantity is available!" <<endl;
					if( quantity[index - 1] < no_item) {
						cout << "We do not have the required quantity at the moment." << endl; 	
			}
			else { 
				cout << "Quantity is available!" << endl;
				price = prices[index - 1] * no_item;
				cout << "Your order has been placed successfully!\nYou have ordered " << no_item << " packs of chocolates\n" << "Your total bill is Rs. " << price << endl << endl;
				quantity[index - 1] -= no_item;
				update_quantities(quantity);
			}
				break;

				default:
				cout << "Invalid input." << endl;
				break;	
		}
		
		}
	
		
		file.close();
		}    //case2
		break;
		
		case 3:                    //Beverages
		{
		cout << "___________________________________________________\n";
		cout << "|         Items          |          Price         |\n";
		cout << "---------------------------------------------------\n";
		cout << "|      1.Fresh Juice     |          Rs. 150       |\n";
		cout << "|      2.Soft Drinks     |          Rs. 100       |\n";
		cout << "|      3.Water           |          Rs. 50        |\n";
		cout << "|_________________________________________________|\n";
		
		fstream file;
		file.open("itemnames.txt", ios::in);
		if (!file)
		{
			cout << "There seems to be an error placing order.Please try again later." << endl;	
		break;
		}
		
	 	cout << "Please enter the item you want to order (1-3) : ";
		cin.ignore();
		int index;
		cin >> index;
		if( index < 1 || index > 3) {
			cout << "Invalid Option\n" << endl;
		}
		
		else {
			index = index + 7;
			cout << "What quantity of the item do you want ? ";
			cin >> no_item;
			cout << endl;
			cout << endl;
			
			fstream Qfile("quantity.txt", ios::in);
			int i = 0;
									
			int price = 0;
			int temp = index;
			switch(index) {
				case 8: 
					if( quantity[index - 1] < no_item) {
						cout << "We do not have the required quantity at the moment." << endl; 	
			}
			else { 
				cout << "Quantity is available!" << endl;
				price = prices[index - 1] * no_item;
				cout << "Your order has been placed successfully!\nYou have ordered " << no_item << " bottle of fresh juice\n" << "Your total bill is Rs. " << price << endl << endl;
				quantity[index] -= no_item;
				update_quantities(quantity);
			}
				break;
				case 9: 
					if( quantity[index - 1] < no_item){
						cout << "We do not have the required quantity at the moment." << endl; 	
			}
			else { 
				cout << "Quantity is available!" << endl;
				price = prices[index - 1] * no_item;
				cout << "Your order has been placed successfully!\nYou have ordered " << no_item << " can of soft drinks\n" << "Your total bill is Rs. " << price << endl << endl;
				quantity[index - 1] -= no_item;
				update_quantities(quantity);
			}
				break;
				case 10: 
					cout << "Quantity is available!" <<endl;
					if( quantity[index - 1] < no_item) {
						cout << "We do not have the required quantity at the moment." << endl; 	
			}
			else { 
				cout << "Quantity is available!" << endl;
				price = prices[index - 1] * no_item;
				cout << "Your order has been placed successfully!\nYou have ordered " << no_item << " bottle of water\n" << "Your total bill is Rs. " << price << endl << endl;
				quantity[index - 1] -= no_item;
				update_quantities(quantity);
			}
				break;
				
				default:
				cout << "Invalid input." << endl;
				break;	
		}
		break;
		}
	
		
		file.close();
		
		
		}     //case 3
		}    //switch
		}    //func
	
	//to respond to the sched orders
	 void respondOrder() 
	 {
    	 	string response;
    		cout << "Enter which order you wish to deliver (Write exact order): ";
    		cin.ignore();
    		getline(cin, response);
			removeLineFromFile("schedOrders.txt",response);
			cout << "Now Enter order transaction: ";
			int choice;
    		store_data();
			order(items, prices, quantity, choice);
	}

int main () 
{
	
	int choice;
	
	
	int user_type;
	char** usernames;
	char** passwords;
	char username[50];
    	char password[50];
	int num_users = 5;
	bool running = true; 
	int order_op;
	usernames = new char*[num_users];
	passwords = new char*[num_users];
	for ( int i = 0; i < num_users; i++) {
	usernames[i] = new char[50];
	passwords[i] = new char[50];
	}
	fstream Qfile("quantity.txt", ios::in);
	int i = 0;
	// storing the quantities in the array
	while(Qfile >> prev_quantities[i]) {
		i++;
	}
	
	cout << "\n\n";
	cout << "\t\t\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\n";
	cout << "\t\t\\\\\\\\\\\\\\Welcome to Cafe Digital System :D\\\\\\\\\\\\\\\\\n";
	cout << "\t\t\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\n";
	cout << "\n\n";
	cout << "Enter 1 if you are a Student/Staff member :\n";
	cout << "Enter 2 if you are an Employee :\n";
	cout << "Enter 3 if you are the Admin :\n";
	cin >> user_type;
	
	//Students
	if (user_type==1) {
	cout << "Enter your Username : ";
	cin >> username;
	
	fstream file;
	file.open("studentlogin.txt", ios:: in);
	if (!file)
		{
			cout << "There seems to be an error logging in.Please try again later." << endl;
			return 1;
		}
	bool found = false;
	for( int i = 0; i < num_users ; i++) {
	file >> usernames[i] >> passwords[i];

		if (strcmp(usernames[i], username) == 0) {
		 	cout << "Enter your password : ";
		 	cin >> password;
			 	if (strcmp(passwords[i], password)==0) {
			 	found = true;
			 	}
		}		
	    	}

	    file.close();

	    if (found) {
		cout << "Login successful! Proceeding..." << endl << endl;
		
		do {
			cout << "Enter (1-4) :\n";
			cout << "1. Place/Schedule Orders\n";
			cout << "2. Check your notifications\n"; 
			cout << "3. Lodge any complaint\n";
			cout << "4. Exit the system" << endl;
			
			int choice;
			cin >> choice;
			
			if (choice ==1) {
			cout << "Enter 1 to place an order :\n";
			cout << "Enter 2 to schedule an order :\n";
			cin >> order_op;
			switch(order_op) {
			case 1:
				store_data();
				order(items, prices, quantity, choice);
				break;
			case 2:
				schedOrder();
				break;
			default:
				cout << "Invalid input\n";
				break;
			}
			}
			
			else if (choice == 2) {
			int op1;
			while(running) {
			cout << "Enter 1 to see Notification :\n";
			cout << "Enter 2 to exit : ";
			cin >> op1;
			
			switch (op1) {
			case 1:
    				seeNotif();
    				break;
    			case 2:
    				cout << "You have exited.\n";
    				running = false;
    				break;
    			default:
    				cout << "Invalid input.\n";
    				break;
    					}
    				}
    			}
    				
			else if (choice == 3) {
			Makecomplaint();
				}
			else if(choice == 4) {
				cout << "You have exited the system. " << endl;
				break;
				}
			else cout << "Invalid Input. Please try again.\n" << endl;
				continue;
				
		}
			while( running );
	  		} 
	   	 
	   	 else {
			cout << "Username or password is incorrect." << endl;
	    	 }
	    	
	// Deallocate memory
    	for (int i = 0; i < num_users; i++) {
        	delete[] usernames[i];
        	delete[] passwords[i];
    	}
    	delete[] usernames;
    	delete[] passwords;
    	}    //user_type 1
    	
    	
    	//Employees
    	else if (user_type==2) {
    	char** usernames;
	char** passwords;
	char username[50];
    	char password[50];
    	usernames = new char*[num_users];
	passwords = new char*[num_users];
	for ( int i = 0; i < num_users; i++) {
	usernames[i] = new char[50];
	passwords[i] = new char[50];
	}

	fstream file;
	file.open("employeelogin.txt", ios:: in);
	if (!file)
		{
			cout << "There seems to be an error logging in.Please try again later." << endl;
			return 1;
		}
	bool found = false;
	cout << "Enter your Username : ";
	cin >> username;
	for( int i = 0; i < num_users ; i++) {
	file >> usernames[i] >> passwords[i];

		if (strcmp(usernames[i], username) == 0) {
		 	cout << "Enter your password : ";
		 	cin >> password;
			 	if (strcmp(passwords[i], password)==0) {
			 	found = true;
			 	}
		}		
	    	}

	    file.close();

	    if (found) {
			cout << "Login successful! Proceeding...\n" << endl;
		while(true)
		{
	    char choice_emp;
		cout << "Enter (1-5) :\n";
		cout << "1. Take orders\n";
		cout << "2. Search Items\n";
		cout << "3. View and respond to scheduled orders\n";
		cout << "4. Stock calculation\n";
		cout << "5. Exit the system\n";
		cin >> choice_emp;
		
			if (choice_emp == '1') {
				store_data();
				order(items, prices, quantity, choice);
			}
			else if (choice_emp == '2') {
				char item[256];
				const char* filename = "itemnames.txt";
				cout << "Please enter the item you want to search for : ";
				cin.ignore();
			 	cin.getline(item, 256);
			 	if (search(filename, item)) {
					cout << item << " is available! " << endl;
				}
			else cout << "This item is unavailable at the moment." << endl;
			}
			
			else if ( choice_emp == '3') {
				int op;
				while (running) {
				cout << "Enter 1 to view orders :\n";
				cout << "Enter 2 to respond to orders :\n";
				cout << "Enter 3 to exit :\n";
				cin >> op;
				switch (op) {
				case 1 : 
					seeOrder();
					break;
				case 2 :
					respondOrder();
					break;
				case 3 : 
					cout << "You have exited.\n";
					running = false;
					break;
					
				default :
					cout << "Invalid input.";
					break;
					}
				}
			}
			else if ( choice_emp == '4') {
				store_data();
				salesCalc();
			}
			else if ( choice_emp == '5' ) {
				cout << "You have exited the system.\n";
				break;
			} 
			
		else cout << "Invalid input. Please try again.\n";
		}
		
		}
		else cout << "Username or password is incorrect." << endl;
	    	
	// Deallocate memory
    	for (int i = 0; i < num_users;i++) {
        	delete[] usernames[i];
        	delete[] passwords[i];
    	}
    	delete[] usernames;
    	delete[] passwords;
    	}	//user_type 2
    	
    	
    	
    	//Admin
    	else if (user_type==3) {
    	num_users = 1;
	char username[50];
    	char password[50]; 
	
    	//Hard coding as only 1 admin
    	char correct_username[50];
    	char correct_password[50];
    	
	cout << "Enter your Username : ";
	cin >> username;

	fstream file;
	file.open("adminlogin.txt", ios:: in);
	if (!file)
		{
			cout << "There seems to be an error logging in.Please try again later." << endl;
			return 1;
		}
	bool found = false;
	for( int i = 0; i < num_users ; i++) {
	file >> correct_username >> correct_password;

		if (strcmp(username, correct_username) == 0) {
		 	cout << "Enter your password : ";
		 	cin >> password;
			 	if (strcmp(password, correct_password)==0) {
			 	found = true;
			 	}
			}		
	    	}

	    file.close();

	    if (found) {
		cout << "Login successful! Proceeding...\n" << endl;
		while(true)
		{
	    char choice_adm;
	    int op2;
		cout << "Enter (1-6) :\n";
		cout << "1. Restock items\n";
		cout << "2. Remove employee/student credentials\n";
		cout << "3. Display Notifications\n";
		cout << "4. View and respond to scheduled orders\n";
		cout << "5. See complaints and respond to them\n";
		cout << "6. Exit the system\n";
		cin >> choice_adm;

			if (choice_adm == '1')
			{
				store_data();
				ReStock(items, prices, quantity, choice);
			}
			else if (choice_adm == '2')
			{
				char remove_choice;
				do
				{
				cout << "Who do you wish to remove?\n"
				     << "1. Employees\n"
					 << "2. Student\n";
				cin >> remove_choice;
				} while (remove_choice != '1' && remove_choice != '2');

					string name;
					cout << "Enter Username to remove:\n";
					cin.ignore();
					getline(cin,name);
					string pass;
					cout << "Enter password of this User:\n";
					getline(cin, pass);
					name += " ";
					name += pass;
					if (remove_choice == '1')
						removeLineFromFile("employeelogin.txt", name);
					else if (remove_choice == '2')
						removeLineFromFile("studentlogin.txt", name);
					cout << "User removed successfully!\n";
				
			}
			else if (choice_adm=='3') {
			while (running) {
			cout << "Enter 1 to Display a notification :\n";
			cout << "Enter 2 to exit : ";
			cin >> op2;
			
			switch (op2) {
			case 1:
				displayNotif();
				break;
			case 2:
				cout << "You have exited.\n";
				running = false;
				break;
			default:
				cout << "Invalid input. Please try again.\n";
				running = false;
				break;
			}
				}
			}
			else if (choice_adm == '4')
			{
				int op;
				while (running) {
				cout << "Enter 1 to view orders : \n";
				cout << "Enter 2 to respond to orders : \n";
				cout << "Enter 3 to exit : \n";
				cin >> op;
				switch (op) {
				case 1 : 
					seeOrder();
					break;
				case 2 :
					respondOrder();
					break;
				case 3 : 
					cout << "You have exited.\n";
					running = false;
					break;
					
				default :
					cout << "Invalid input.";
					break;
					}
				}
			}
			
			else if (choice_adm=='5') {
			while (running) {
			cout << "Enter 1 to see complaint/complaints :\n";
			cout << "Enter 2 to respond to a complaint/complaints :\n";
			cout << "Enter 3 to exit :\n";
			cin >> op2;

			switch (op2) {
			case 1:
				seeComplaint(); 
				break;
			case 2:
				respondComplaint();
				break;
			case 3:
				cout << "You have exited.\n";
				running = false;
				break;
			default:
				cout << "Invalid Input. Please try again.\n";
				break;
				}
			}
			}
			else
			{
				cout << "You have exited.\n";
				break;
			}
			}
		}
	   	 
	   	 else {
			cout << "Username or password is incorrect." << endl;
	    	 }
	}
	    	
		else cout << "Invalid input. Please try again." << endl;
		
		
	return 0;
	}
    	
    	
    	
    	
    	
    	
    	
    	
    	
    	
    	
    	
    	
    	
    	
    	
    	
    	
    	
    	
    	
    	
    	
    	
