#ifndef ADMIN_H
#define ADMIN_H

#include "stocks.h"
#include "students.h"

void respondOrder();
void ReStock(char** items, int* prices, int* quantity, int choice);
void respondComplaint();
void seeComplaint();

#endif