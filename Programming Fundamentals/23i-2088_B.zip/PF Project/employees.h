#ifndef EMPLOYEES_H
#define EMPLOYEES_H

#include "stocks.h"
#include "students.h"

void seeOrder();

bool search(const char* filename, const char* item);

void salesCalc();

#endif