#ifndef STUDENTS_H
#define STUDENTS_H

#include "stocks.h"

void order(char** items, int* prices, int* quantity, int choice);

void seeNotif();

void Makecomplaint();

void schedOrder();

#endif