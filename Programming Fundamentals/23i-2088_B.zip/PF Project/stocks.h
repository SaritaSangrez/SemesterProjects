#ifndef STOCKS_H
#define STOCKS_H

#include<iostream>
using namespace std;

	char** items = new char*[10];
	/*
	for(int i = 0; i < 10; i++)
	{
		items[i] = new char[50];
	}*/
		

	int* prices = new int[10];

	int* quantity = new int[10];

	int* total_prices = new int[10];


void update_quantities(int* quantity);

void store_data();

#endif