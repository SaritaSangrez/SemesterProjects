#ifndef STRUCTURES_H
#define STRUCTURES_H

#include <iostream>
#include <climits> // For INT_MAX

using namespace std;

// Linked list

// node in list, represents connection
struct AdjListNode {
    int dest;
    int weight;
    AdjListNode* next;
};

struct Graph {
    int V; // number of vertices
    AdjListNode** array; // array of adjacency lists
    int* degrees;  // array to store degree of each vertex (A*)
};

// Function to create a graph
Graph* createGraph(int V) {
    Graph* graph = new Graph;
    graph->V = V;

    // allocate memory for adjacency list array
    graph->array = new AdjListNode*[V];
    graph->degrees = new int[V];

    // initialize
    for (int i = 0; i < V; ++i) {
        graph->array[i] = NULL;
        graph->degrees[i] = 0;
    }

    return graph;
}


// Function to add undirected Edge
void addEdge(Graph* graph, int src, int dest, int weight) {
    // Add edge from src to dest
    AdjListNode* newNode = new AdjListNode;
    newNode->dest = dest;
    newNode->weight = weight;
    newNode->next = graph->array[src];
    graph->array[src] = newNode;
    graph->degrees[src]++;    // for A*

    // since undirected, add edge from dest to src
    AdjListNode* newNode2 = new AdjListNode;
    newNode2->dest = src;
    newNode2->weight = weight; 
    newNode2->next = graph->array[dest];
    graph->array[dest] = newNode2;
    graph->degrees[dest]++;   // for A*
}

// Min Heap for Priority queue
struct MinHeapNode {
    int v;
    int dist;
};

struct MinHeap {
    int size;      // current number of elements
    int capacity;  // max possible size
    int* pos;      // needed for decreaseKey()
    MinHeapNode** array;
};

bool isMinHeapEmpty(MinHeap* minHeap) {
    return minHeap->size == 0;
}

MinHeapNode* newMinHeapNode(int v, int dist) {
    MinHeapNode* minHeapNode = new MinHeapNode;
    minHeapNode->v = v;
    minHeapNode->dist = dist;
    return minHeapNode;
}

MinHeap* createMinHeap(int capacity) {
    MinHeap* minheap = new MinHeap;
    minheap->pos = new int[capacity];
    minheap->size = 0;
    minheap->capacity = capacity;
    minheap->array = new MinHeapNode*[capacity];
    return minheap;
}

void swapMinHeapNode(MinHeapNode** a, MinHeapNode** b) {
    MinHeapNode* temp = *a;
    *a = *b;
    *b = temp;
}

// Heapify and update position
void minHeapify(MinHeap* minHeap, int idx) {
    int smallest, left, right;
    smallest = idx;
    left = 2*idx + 1;
    right = 2*idx + 2;

    if (left < minHeap->size &&
        minHeap->array[left]->dist < minHeap->array[smallest]->dist)
        smallest = left;

    if (right < minHeap->size &&
        minHeap->array[right]->dist < minHeap->array[smallest]->dist)
        smallest = right;

    if (smallest != idx) {
        MinHeapNode* smallestNode = minHeap->array[smallest];
        MinHeapNode* idxNode = minHeap->array[idx];

        // swap pos
        minHeap->pos[smallestNode->v] = idx;
        minHeap->pos[idxNode->v] = smallest;
        // swap nodes
        swapMinHeapNode(&minHeap->array[smallest], &minHeap->array[idx]);
        minHeapify(minHeap, smallest);
    }
}


MinHeapNode* extractMin(MinHeap* minHeap) {
    if (isMinHeapEmpty(minHeap))
        return NULL;

    MinHeapNode* root = minHeap->array[0];

    // replace root node last node
    MinHeapNode* lastNode = minHeap->array[minHeap->size - 1];
    minHeap->array[0] = lastNode;

    // update pos
    minHeap->pos[root->v] = minHeap->size - 1;
    minHeap->pos[lastNode->v] = 0;

    // heapify
    minHeap->size = minHeap->size - 1;
    minHeapify(minHeap, 0);

    return root;
}


// Function to decrease dist value of a vertex
void decreaseKey(MinHeap* minHeap, int v, int dist) {
    int i = minHeap->pos[v];

    // update dist
    minHeap->array[i]->dist = dist;

    // travel up while complete tree is not heapified
    while (i && minHeap->array[i]->dist < minHeap->array[(i-1) / 2]->dist) {
        // swap node with its parent
        minHeap->pos[minHeap->array[i]->v] = (i-1) / 2;
        minHeap->pos[minHeap->array[(i-1) / 2]->v] = i;
        swapMinHeapNode(&minHeap->array[i], &minHeap->array[(i-1) / 2]);

        // move to parent idx
        i = (i - 1) / 2;
    }

}

bool isInMinHeap(MinHeap *minHeap, int v) {
    if (minHeap->pos[v] < minHeap->size)
        return true;
    return false;
}

#endif

