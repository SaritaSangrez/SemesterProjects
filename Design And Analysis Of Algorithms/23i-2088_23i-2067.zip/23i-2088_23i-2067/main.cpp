#include <iostream>
#include <fstream>
#include <string>
#include <chrono> 
#include "structures.h"

using namespace std;
using namespace std::chrono;    

// find max node ID in file
int findMaxNodeID(const string& filename) {
ifstream file(filename);
    if (!file.is_open()) {
        cout << "Error opening file: " << filename << endl;
        return -1;
    }
    int u, v, w;
    int maxID = 0;
    while (file >> u >> v >> w) {
        if (u > maxID) 
            maxID = u;
        if (v > maxID) 
            maxID = v;
    }
    file.close();
    return maxID;
}


// Dijsktra's algorithm
void dijkstra(Graph *graph, int src, int dest) {
    int V = graph->V;

    int* dist = new int[V];
    int* parent = new int[V];

    MinHeap *minHeap = createMinHeap(V);

    // dist value for all nodes
    for (int v = 0; v < V; ++v) {
        dist[v] = INT_MAX;
        parent[v] = -1;
        minHeap->array[v] = newMinHeapNode(v, dist[v]);
        minHeap->pos[v] = v;
    }

    minHeap->array[src] = newMinHeapNode(src, 0);  // src dist 0
    minHeap->pos[src] = src;
    dist[src] = 0;
    decreaseKey(minHeap, src, 0);

    minHeap->size = V;

    // Time measurement
    auto start = high_resolution_clock::now();

    while(!isMinHeapEmpty(minHeap)) {
        MinHeapNode* MinHeapNode = extractMin(minHeap);
        int u = MinHeapNode->v;

        // stop early if dest reached
        if (u == dest) {
            break;
        }

        // traverse all vertices
        AdjListNode *temp = graph->array[u];
        while (temp!=NULL) {
            int v = temp->dest;

            // check if shorter distance
            if (isInMinHeap(minHeap, v) && dist[u] != INT_MAX &&
                temp->weight + dist[u] < dist[v]) {
                    dist[v] = dist[u] + temp->weight;
                    parent[v] = u;

                    decreaseKey(minHeap, v, dist[v]);
                }
            temp = temp->next;
        }
    }

    // end time measurement
    auto stop = high_resolution_clock::now();
    auto duration = duration_cast<microseconds>(stop - start);

    // output
    cout << "\n\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\n";
    cout << "\\\\ Dijkstra Algorithm Results \\\\\n";
    cout << "\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\n";
    if (dist[dest] == INT_MAX) {
        cout << "No path found between " << src << " and " << dest << endl;
    } 
    else {
        cout << "Shortest Distance: " << dist[dest] << endl;
        cout << "Execution Time: " << duration.count() << " microseconds" << endl;

        // print path
        cout << "Path: ";
        int curr = dest;
        while (curr != -1) {
            cout << curr;
            curr = parent[curr];
            if (curr != -1) cout << " <- ";
        }
        cout << endl;
    }

    delete[] dist;
    delete[] parent;
}

void A_Star(Graph *graph, int src, int dest) {
    int V = graph->V;
    int* g_score = new int[V];

    int* f_score = new int[V];

    int* parent = new int[V];
    MinHeap* minHeap = createMinHeap(V);

    // initialize
    for (int v = 0; v < V; ++v) {
        g_score[v] = INT_MAX;
        f_score[v] = INT_MAX;
        parent[v] = -1;
        
        // Initialize heap with fscore 
        minHeap->array[v] = newMinHeapNode(v, f_score[v]);
        minHeap->pos[v] = v;
    }

    g_score[src] = 0;
    // f(src)= g(src)+h(src)
    f_score[src] = 0 + graph->degrees[src];

    // update src in heap with fscore
    decreaseKey(minHeap, src, f_score[src]); 
    minHeap->size = V;

    auto start = high_resolution_clock::now();

    while (!isMinHeapEmpty(minHeap)) {
        MinHeapNode *minNode = extractMin(minHeap);
        int u = minNode->v;

        // dest found
        if (u == dest) {
            break;
        }

        // other nodes unreachable
        if (f_score[u] == INT_MAX) break;

        AdjListNode *temp = graph->array[u];
        while (temp!=NULL) {
            int v = temp->dest;
            int weight = temp->weight;

            if (g_score[u] != INT_MAX && g_score[u] + weight < g_score[v]) {
                parent[v] = u;
                g_score[v] = g_score[u] + weight;

                // update f(v)= g(v)+h(v)
                int h_v = graph->degrees[v];
                f_score[v] = g_score[v] + h_v;

                // update queue
                if (isInMinHeap(minHeap, v)) {
                    decreaseKey(minHeap, v, f_score[v]);
                }
            }
            temp = temp->next;
        }

    }

    auto stop = high_resolution_clock::now();
    auto duration = duration_cast<microseconds>(stop - start);

    // output
    cout << "\n\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\n";
    cout << "\\\\ A* Star Algorithm Results  \\\\\n";
    cout << "\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\n";

    if (g_score[dest] == INT_MAX) {
        cout << "No path found between " << src << " and " << dest << endl;
    } else {
        cout << "Shortest Distance (g_score): " << g_score[dest] << endl;
        cout << "Execution Time: " << duration.count() << " microseconds" << endl;
        
        //Backtrack
        cout << "Path: ";
        int curr = dest;
        while (curr != -1) {
            cout << curr;
            curr = parent[curr];
            if (curr != -1) cout << " <- ";
        }
        cout << endl;
    }

    delete[] g_score;
    delete[] f_score;
    delete[] parent;

}


int main() {
    string filename = "social-network-proj-graph.txt";
    
    cout << "Reading file to get graph size..." << endl;
    int maxID = findMaxNodeID(filename);
    
    if (maxID == -1) return 1;

    int V = maxID + 1; 
    cout << "Max Node ID: " << maxID << ".\nCreating Graph with " << V << " nodes." << endl;

    // create graph
    Graph* graph = createGraph(V);

    // Add edges
    ifstream file(filename);
    int u, v, w;
    int edgeCount = 0;
    while (file >> u >> v >> w) {
        addEdge(graph, u, v, w);
        edgeCount++;
    }
    file.close();
    cout << "Graph loaded successfully! (" << edgeCount << " edges)" << endl;

    int srcNode, destNode;
    cout << "\nEnter Source User ID: ";
    cin >> srcNode;
    cout << "Enter Destination User ID: ";
    cin >> destNode;

    // check bounds
    if(srcNode > maxID || destNode > maxID || srcNode < 0 || destNode < 0) {
        cout << "Invalid IDs. Please enter values between 0 and " << maxID << endl;
        return 0;
    }

    // Run dijkstra
    dijkstra(graph, srcNode, destNode);
    // Run A* star
    A_Star(graph, srcNode, destNode);

    return 0;

}

