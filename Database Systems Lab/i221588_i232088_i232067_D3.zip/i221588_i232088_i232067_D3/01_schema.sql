CREATE DATABASE IF NOT EXISTS db2;
USE db2;

SET FOREIGN_KEY_CHECKS = 0;

DROP TABLE IF EXISTS VolunteerAnimal;
DROP TABLE IF EXISTS Treatment;
DROP TABLE IF EXISTS Appointment;
DROP TABLE IF EXISTS Adoption;
DROP TABLE IF EXISTS Animal;
DROP TABLE IF EXISTS Adopter;
DROP TABLE IF EXISTS Volunteer;
DROP TABLE IF EXISTS Veterinarian;
DROP TABLE IF EXISTS Admin;
DROP TABLE IF EXISTS Staff;
DROP TABLE IF EXISTS ShelterRoom;

SET FOREIGN_KEY_CHECKS = 1;

-- 1. ShelterRoom
CREATE TABLE ShelterRoom (
    RoomID INT AUTO_INCREMENT PRIMARY KEY,
    RoomType ENUM('Kennel','CatRoom','Isolation','General','Other') NOT NULL,
    Capacity INT NOT NULL CHECK (Capacity > 0),
    OccupiedCount INT NOT NULL DEFAULT 0
);

-- 2. Animal
CREATE TABLE Animal (
    AnimalID INT AUTO_INCREMENT PRIMARY KEY,
    Name VARCHAR(50) NOT NULL,
    Species ENUM('Dog','Cat','Rabbit','Other') NOT NULL,
    Breed VARCHAR(50),
    Gender ENUM('Male','Female') NOT NULL,
    DateOfBirth DATE NOT NULL,
    Status ENUM('Available','InTreatment','Adopted','Deceased') DEFAULT 'Available',
    ShelterRoomID INT NOT NULL,
    FOREIGN KEY (ShelterRoomID) REFERENCES ShelterRoom(RoomID)
        ON DELETE CASCADE
        ON UPDATE CASCADE
);

-- 3. Adopter
CREATE TABLE Adopter (
    AdopterID INT AUTO_INCREMENT PRIMARY KEY,
    FullName VARCHAR(100) NOT NULL,
    Phone VARCHAR(15) NOT NULL,
    Email VARCHAR(100) UNIQUE NOT NULL,
    Address VARCHAR(200),
    CNIC VARCHAR(15) NOT NULL
);

-- 4. Adoption
CREATE TABLE Adoption (
    AdoptionID INT AUTO_INCREMENT PRIMARY KEY,
    AdoptionDate DATE NOT NULL,
    AnimalID INT UNIQUE NOT NULL,
    AdopterID INT NOT NULL,
    AdoptionFile VARCHAR(255),
    FOREIGN KEY (AnimalID) REFERENCES Animal(AnimalID)
        ON DELETE CASCADE
        ON UPDATE CASCADE,
    FOREIGN KEY (AdopterID) REFERENCES Adopter(AdopterID)
        ON DELETE CASCADE
        ON UPDATE CASCADE
);

-- 5. Staff (superclass)
CREATE TABLE Staff (
    StaffID INT AUTO_INCREMENT PRIMARY KEY,
    Name VARCHAR(100) NOT NULL,
    Phone VARCHAR(15),
    Email VARCHAR(100) UNIQUE NOT NULL,
    Role ENUM('Admin','Veterinarian','Volunteer') NOT NULL,
    Username VARCHAR(50) UNIQUE NOT NULL,
    PasswordHash VARCHAR(255) NOT NULL
);

-- 6. Admin (subclass of Staff)
CREATE TABLE Admin (
    AdminID INT PRIMARY KEY,
    Salary DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (AdminID) REFERENCES Staff(StaffID)
        ON DELETE CASCADE
        ON UPDATE CASCADE
);

-- 7. Veterinarian (subclass of Staff)
CREATE TABLE Veterinarian (
    VetID INT PRIMARY KEY,
    Specialization VARCHAR(100),
    LicenseNo VARCHAR(20),
    Salary DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (VetID) REFERENCES Staff(StaffID)
        ON DELETE CASCADE
        ON UPDATE CASCADE
);

-- 8. Volunteer (subclass of Staff)
CREATE TABLE Volunteer (
    VolunteerID INT PRIMARY KEY,
    Availability VARCHAR(50),
    FOREIGN KEY (VolunteerID) REFERENCES Staff(StaffID)
        ON DELETE CASCADE
        ON UPDATE CASCADE
);

-- 9. Treatment
CREATE TABLE Treatment (
    TreatmentID INT AUTO_INCREMENT PRIMARY KEY,
    AnimalID INT NOT NULL,
    VetID INT NOT NULL,
    TreatmentDate DATE NOT NULL,
    Diagnosis VARCHAR(200),
    Prescription VARCHAR(200),
    FOREIGN KEY (AnimalID) REFERENCES Animal(AnimalID)
        ON DELETE CASCADE
        ON UPDATE CASCADE,
    FOREIGN KEY (VetID) REFERENCES Veterinarian(VetID)
        ON DELETE CASCADE
        ON UPDATE CASCADE
);

-- 10. Appointment
CREATE TABLE Appointment (
    AppointmentID INT AUTO_INCREMENT PRIMARY KEY,
    AnimalID INT NOT NULL,
    VetID INT NOT NULL,
    DateTime DATETIME NOT NULL,
    Status ENUM('Scheduled','Completed','Cancelled') DEFAULT 'Scheduled',
    FOREIGN KEY (AnimalID) REFERENCES Animal(AnimalID)
        ON DELETE CASCADE
        ON UPDATE CASCADE,
    FOREIGN KEY (VetID) REFERENCES Veterinarian(VetID)
        ON DELETE CASCADE
        ON UPDATE CASCADE
);

-- 11. VolunteerAnimal (associative entity)
CREATE TABLE VolunteerAnimal (
    VolunteerID INT NOT NULL,
    AnimalID INT NOT NULL,
    AssignedDate DATE NOT NULL,
    HoursPerWeek INT CHECK (HoursPerWeek > 0),
    PRIMARY KEY (VolunteerID, AnimalID),
    FOREIGN KEY (VolunteerID) REFERENCES Volunteer(VolunteerID)
        ON DELETE CASCADE
        ON UPDATE CASCADE,
    FOREIGN KEY (AnimalID) REFERENCES Animal(AnimalID)
        ON DELETE CASCADE
        ON UPDATE CASCADE
);
