USE db2;

-- 1. ShelterRoom
INSERT INTO ShelterRoom (RoomType, Capacity)
VALUES
    ('Kennel', 10),
    ('Kennel', 8),
    ('CatRoom', 12),
    ('CatRoom', 15),
    ('Isolation', 5),
    ('General', 20),
    ('Other', 10),
    ('CatRoom', 14),
    ('CatRoom', 9),
    ('Isolation', 6),
    ('General', 22),
    ('Other', 12);

-- 2. Staff 
INSERT INTO Staff (Name, Phone, Email, Role, Username, PasswordHash)
VALUES
    ('Sarah Ahmed', '0300-7894561', 'sarah.admin@shelter.org', 'Admin', 'sarahA', '7c4a8d09ca3762af61e59520943dc26494f8941b'),
    ('Dr. Hamza Raza', '0312-9988776', 'hamza.vet@shelter.org', 'Veterinarian', 'drHamza', '7c222fb2927d828af22f592134e8932480637c0d'),
    ('Dr. Ayesha Khan', '0345-6677889', 'ayesha.vet@shelter.org', 'Veterinarian', 'drAyesha', '7c222fb2927d828af22f592134e8932480637c0d'),
    ('Zain Ali', '0333-5566778', 'zain.vol@shelter.org', 'Volunteer', 'zainV', '7c222fb2927d828af22f592134e8932480637c0d'),
    ('Hiba Fatima', '0301-6655443', 'hiba.vol@shelter.org', 'Volunteer', 'hibaV', '7c222fb2927d828af22f592134e8932480637c0d'),
    ('Adeel Shah', '0315-2233445', 'adeel.vol@shelter.org', 'Volunteer', 'adeelV', '7c222fb2927d828af22f592134e8932480637c0d'),
    ('Imran Malik', '0341-9988223', 'imran.vol@shelter.org', 'Volunteer', 'imranV', '7c222fb2927d828af22f592134e8932480637c0d'),
    ('Dr. Saad Khan', '0308-1122443', 'saad.vet@shelter.org', 'Veterinarian', 'drSaad', '7c222fb2927d828af22f592134e8932480637c0d'),
    ('Areeba Zafar', '0332-7766554', 'areeba.vol@shelter.org', 'Volunteer', 'areebaV', '7c222fb2927d828af22f592134e8932480637c0d'),
    ('Jawad Farooq', '0314-5544332', 'jawad.vol@shelter.org', 'Volunteer','jawadV', '7c222fb2927d828af22f592134e8932480637c0d'),
    ('Zoya Malik', '0306-8732211', 'zoya.vol@shelter.org', 'Volunteer','zoyaV', '7c222fb2927d828af22f592134e8932480637c0d'),
    ('Talha Rizvi', '0321-6655441', 'talha.vol@shelter.org', 'Volunteer','talhaV', '7c222fb2927d828af22f592134e8932480637c0d'),
    ('Ayesha Mir', '0312-8844321', 'ayesha.vol@shelter.org', 'Volunteer','ayeshaV', '7c222fb2927d828af22f592134e8932480637c0d'),
    ('Hassan Raza', '0305-8899443', 'hassan.vol@shelter.org', 'Volunteer','hassanV','7c222fb2927d828af22f592134e8932480637c0d'),
    ('Mehreen Qazi', '0331-5566789', 'mehreen.vol@shelter.org', 'Volunteer','mehreenV','7c222fb2927d828af22f592134e8932480637c0d');

-- 3. Admin
INSERT INTO Admin (AdminID, Salary)
VALUES
    (1, 85000);

-- 4. Veterinarian
INSERT INTO Veterinarian (VetID, Specialization, LicenseNo, Salary)
VALUES
    (2, 'General Veterinary Medicine', 'VET-1021', 120000),
    (3, 'Surgery & Emergency Care', 'VET-1143', 140000),
    (8, 'Dermatology', 'VET-2144', 130000);

-- 5. Volunteers
INSERT INTO Volunteer (VolunteerID, Availability)
VALUES
    (4, 'Weekends'),
    (5, 'Evenings'),
    (6, 'Weekdays'),
    (7, 'Flexible'),
    (9, 'Weekdays'),
    (10, 'Weekends'),
    (11, 'Mornings'),
    (12, 'Afternoons'),
    (13, 'Flexible'),
    (14, 'Weekends'),
    (15, 'Evenings');

-- 6. Adopter
INSERT INTO Adopter (FullName, Phone, Email, Address, CNIC)
VALUES
    ('Ali Hassan', '0331-2345678', 'ali.hassan@gmail.com', 'G-11 Islamabad', '37405-1234567-1'),
    ('Mariam Khalid', '0305-9876543', 'mariam.khalid@yahoo.com', 'DHA Lahore', '35201-9876543-2'),
    ('Usman Tariq', '0348-5566992', 'usman.t@gmail.com', 'F-10 Islamabad', '37406-1122334-5'),
    ('Fatima Noor', '0322-1122334', 'fatima.noor@hotmail.com', 'Bahria Town', '61101-3344556-8'),
    ('Shoaib Rehman', '0303-6677882', 'shoaib.r@gmail.com', 'Gulberg Lahore', '35202-5566778-3'),
    ('Zulfiqar Hussain', '0307-6677881', 'zulfiq.h@gmail.com', 'Sargodha Cantt', '33202-5566778-9'),
    ('Rabia Shah', '0331-5566988', 'rabia.shah@gmail.com', 'Wapda Town', '61101-9988776-3'),
    ('Farhan Ali', '0342-2233566', 'farhanAli@gmail.com', 'Askari 10', '37405-4455667-2'),
    ('Amina Farooq', '0323-1122994', 'aminaF@hotmail.com', 'Faisal Town', '35101-1122334-9'),
    ('Aqsa Mushtaq', '0345-1122399', 'aqsa.mushtaq@gmail.com', 'Johar Town', '35201-5566889-1');

-- 7. Animal 
INSERT INTO Animal (Name, Species, Breed, Gender, DateOfBirth, Status, ShelterRoomID)
VALUES
    ('Buddy', 'Dog', 'Labrador', 'Male', '2021-04-12', 'Available', 1),
    ('Luna', 'Cat', 'Persian', 'Female', '2022-07-18', 'Available', 3),
    ('Charlie', 'Dog', 'German Shepherd', 'Male', '2020-09-30', 'InTreatment', 5),
    ('Milo', 'Cat', 'Siamese', 'Male', '2021-11-21', 'Available', 4),
    ('Bella', 'Rabbit', 'Dutch', 'Female', '2023-03-10', 'Available', 7),
    ('Rocky', 'Dog', 'Mixed Breed', 'Male', '2019-06-15', 'Adopted', 2),
    ('Coco', 'Cat', 'British Shorthair', 'Female', '2020-12-01', 'Available', 3),
    ('Shadow', 'Dog', 'Husky', 'Male', '2022-01-21', 'Available', 1),
    ('Snowy', 'Rabbit', 'Lionhead', 'Female', '2023-05-12', 'Available', 7),
    ('Sheru', 'Cat', 'Tabby', 'Female', '2021-08-10', 'Available', 4),
    ('Ruby', 'Rabbit', 'Rex', 'Female', '2023-01-05', 'Adopted', 7),
    ('Tiger', 'Cat', 'Bengal', 'Male', '2022-03-11', 'InTreatment', 3),
    ('Bruno', 'Dog', 'Bulldog', 'Male', '2019-11-19', 'Available', 1),
    ('Kitty', 'Cat', 'Mixed', 'Female', '2020-03-12', 'Adopted', 9),
    ('Flash', 'Dog', 'Greyhound', 'Male', '2021-07-09', 'Available', 10),
    ('Puffy', 'Rabbit', 'Angora', 'Female', '2023-06-21', 'Available', 7),
    ('Oscar', 'Cat', 'Sphynx', 'Male', '2021-01-14', 'Available', 3),
    ('Ruby', 'Dog', 'Poodle', 'Female', '2022-12-02', 'Adopted', 2);

-- 8. Adoption 
INSERT INTO Adoption (AdoptionDate, AnimalID, AdopterID, AdoptionFile)
VALUES
    ('2024-03-11', 6, 1, 'adoption_docs/rocky_ali.pdf'),
    ('2024-03-20', 11, 4, 'adoption_docs/ruby_rabbit_fatima.pdf'),
    ('2024-04-02', 14, 7, 'adoption_docs/kitty_rabia.pdf'),
    ('2024-04-18', 18, 5, 'adoption_docs/ruby_dog_shoaib.pdf');

-- 9. Treatment
INSERT INTO Treatment (AnimalID, VetID, TreatmentDate, Diagnosis, Prescription)
VALUES
    (3, 2, '2024-02-15', 'Skin Infection', 'Antibiotic Ointment'),
    (1, 3, '2024-04-02', 'Ear Allergy', 'Corticosteroid Drops'),
    (8, 2, '2024-02-28', 'Eye Irritation', 'Saline Wash'),
    (2, 3, '2024-01-09', 'Respiratory Infection', 'Antibiotics'),
    (9, 2, '2024-04-01', 'Minor Injury', 'Pain Relief'),
    (5, 3, '2024-04-12', 'Allergy', 'Antihistamine'),
    (6, 8, '2024-04-15', 'Ear Infection', 'Ear Drops'),
    (7, 2, '2024-04-17', 'Skin Rash', 'Ointment'),
    (10, 3, '2024-04-19', 'Sprain', 'Pain Relief'),
    (1, 8, '2024-04-22', 'Digestive Issue', 'Probiotics');

-- 10. Appointment
INSERT INTO Appointment (AnimalID, VetID, DateTime, Status)
VALUES
    (1, 2, '2024-05-05 10:00:00', 'Scheduled'),
    (2, 3, '2024-05-05 11:30:00', 'Scheduled'),
    (3, 2, '2024-05-06 09:00:00', 'Completed'),
    (8, 2, '2024-05-06 13:00:00', 'Scheduled'),
    (10, 3, '2024-05-07 15:30:00', 'Cancelled'),
    (6, 2, '2024-05-10 09:00:00', 'Scheduled'),
    (4, 3, '2024-05-10 10:30:00', 'Completed'),
    (5, 8, '2024-05-11 11:00:00', 'Scheduled'),
    (7, 2, '2024-05-11 12:30:00', 'Cancelled'),
    (9, 3, '2024-05-12 14:00:00', 'Scheduled');

-- 11. VolunteerAnimal
INSERT INTO VolunteerAnimal (VolunteerID, AnimalID, AssignedDate, HoursPerWeek)
VALUES
    (4, 1, '2024-03-20', 6),
    (4, 2, '2024-03-22', 4),
    (5, 3, '2024-03-28', 3),
    (6, 4, '2024-04-01', 5),
    (7, 8, '2024-04-02', 2),
    (5, 9, '2024-04-03', 4),
    (9, 11, '2024-04-10', 3),
    (10, 12, '2024-04-11', 4),
    (10, 13, '2024-04-12', 5),
    (6, 14, '2024-04-14', 2),
    (7, 15, '2024-04-15', 3),
    (9, 10, '2024-04-16', 4);
