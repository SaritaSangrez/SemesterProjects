#ifndef ORDER_H
#define ORDER_H

#include "stock.h"

class Order     // class of Order with protected data members and public member functions
{
    protected:
    Stock *ItemsOrdered;
 int QuantityOrdered;
    double TotalPrice;
    int OrderID;
    bool TableReservation;

    public:
    Order(); // PL constructor
    Order(int q, int totalp, int ID, bool r); // parameterized constructor
    ~Order(); // destructor

    // Getters
    int GetOrderID() const;
    const Stock* GetItemsOrdered() const;
    double GetTotalPrice() const;
    int GetQuantityOrdered() const;
    bool GetTableReservation() const;
    int GetNumItems() const
    {
        return 10;
    }

    // Setters
    void SetOrderID(int id);
    void SetQuantityOrdered(int q);
    void SetItemsOrdered(Stock* items);
    void SetTotalPrice(double totalPrice);
    void SetTableReservation(bool reservation);

    // Functions
    double CalculateTotal(); // Computes the total price of items in the order.
    void ProcessOrder(); // Finalizes and confirms the placed order.
};

#endif





