#ifndef USER_H
#define USER_H

#include <iostream>
#include <fstream>
#include <string>
using namespace std;

class User // class of User with protected data members and public member functions
{
    protected:
    char* UserName;
    char* Password;
    int UserType;
    static int num_users;

public:
    User(const char *name, const char *pass, int type); // parameterized constructor
    virtual void Login(); // late binding by virtual key-word [Polymorphism] 
    virtual void Logout(); // late binding by virtual key-word [Polymorphism] 
    virtual void Register(); // late binding by virtual key-word [Polymorphism] 

    // Getters 
    char *GetUserName() const;
    int GetUserType() const;
    char *GetPassword() const;

    // Setters
    void SetUserName( char* name);
    void SetPassword(char* pass);
    void SetUserType(int type);

    friend istream& operator>>(istream& i, User& u); // using extraction operator for taking inputs 
};

#endif
