#ifndef STOCK_H
#define STOCK_H

class Stock
{
    char *item;
    int itemID;
    double price;
    int quantity;
    static int num_items;
    static int totalQuantity;
    static double totalPrice;

    public:
    Stock();
    Stock(char *name, double p, int q, int i);

    // FUNCTIONS
    void UpdateStock(int quantity);
    void viewStock();
    void Statistics();
    void StoreQuantities();
    
    // GETTERS
    char* GetItemName() const;
    double GetItemPrice() const ;
    int GetItemID() const;
    int GetQuantity() const;

    // SETTERS
    void SetItemID(int ID);
    void SetItemName(char *n);
    void SetItemPrice(double p);
    void SetQuantity(int q);
    //friend istream& operator>>(istream& i, Stock& s); // using extraction operator for taking inputs 
    ~Stock();
    static int getNumItems() { return num_items; }
};

#endif