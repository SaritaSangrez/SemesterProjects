#include <iostream>
#include "user.cpp"
#include "customer.cpp"
#include "order.cpp"
#include "complaint.cpp"
#include "notifications.cpp"
#include "employee.cpp"
#include "admin.cpp"
#include <cstdlib>
//include "stock.cpp"
using namespace std;

int main()
{
    User* currentUser = nullptr;   // pointer obj of user
    Customer customer; // making object of class Customers
    Employee employee;  //  obj of employee
    Admin admin;   // obj of admin
    Order order; // making object of class Order
    Complaint complaint;   // obj of complaint
    Notifications notifs;    // obj of notification
    
				// Menuitems that have total 10 items
                Stock menuItems[10] =
                {
                    Stock("Burger", 250, 30, 1),
                    Stock("Pizza", 1200, 25, 2),
                    Stock("Salad", 50, 20, 3),
                   	Stock("Pasta", 1500, 32, 4),
                    Stock("Ice Cream", 90, 20, 5),
                    Stock("Steak",  1500, 10, 6),
                    Stock("Chicken Salad", 100, 27, 7),
                    Stock("Sushi", 200, 0, 8),
                    Stock("Vegetarian Pizza", 1400, 42, 9),
                    Stock("Chocolate Cake", 2000, 20, 10)
                };

    int inpt;
    while (true)
    {
    cout << "\n\n";
    // ANSI escape code for RGB color (Hot Pink)
    cout << "\033[38;2;255;105;180m";  // Set the color to pink
    cout << "\t\t\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\n";
    cout << "\t\t\\\\\\\\\\\\\\WELCOME TO CAFE DIGITAL SYSTEM :D\\\\\\\\\\\\\\\\\n";
    cout << "\t\t\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\n";
    cout << "\033[0m";  // Resets the color to default
cout << "\n\n";
cout << "Enter 1 if you are a Student/Staff member :\n";
cout << "Enter 2 if you are an Employee :\n";
cout << "Enter 3 if you are the Admin :\n";
cout << "Enter 4 to exit the program :\n";

cin >> inpt;

switch (inpt)
{
case 1:
		{
			currentUser = new Customer("huda","sh20", inpt, " ", notifs);
			currentUser->SetUserType(inpt); 
			break;
		}
		case 2: 
        {
            currentUser = new Employee("mishi","sa19", inpt, order);
            break;
            currentUser->SetUserType(inpt); 
        }
        case 3: 
        {
            currentUser = new Admin("seetu","sa19", inpt, complaint, "");
            break;
        }
        case 4: 
        {
            cout << "Exiting the program." << endl;
            return 0;
        }
        default: 
        {
            cout << "Invalid choice. Please try again." << endl;
            //continue;
        }
}



// first user will register and then login
// Admin credentials will be read from file
currentUser->Register();
currentUser->Login();

        bool running = true;
//-------------------------------------------- CUSTOMER ----------------------------------------------
            if (currentUser->GetUserType() == 1)
            {  
        while (running) 
        {               
                cout << "\n\n--------------------------\n";
                cout << "        (CUSTOMER MENU)" << endl;
                cout << "--------------------------\n";
                cout << "1. View Menu" << endl;
                cout << "2. Place Order" << endl;
                cout << "3. View Order History" << endl;
                cout << "4. Make a complaint" << endl;
                cout << "5. Reserve Table" << endl;
                cout << "6. See Notifications" << endl;	
                cout << "7. Logout" << endl;

                int cc; // cc = customerChoice
                cout << "Enter your choice: ";
                cin >> cc;

				switch(cc)
				{
					case 1:
					{
						customer.ViewMenu(menuItems, 10);
						break;
					}

					case 2:
					{
						customer.PlaceOrder(order, menuItems, 10);
						break;
					}
					case 3: 
                	{
               	    	customer.ViewOrderHistory();
                    	break;
                	}
					case 4:
					{
						customer.Makecomplaint();
                        break;
					}
                    case 5:
                    {
                        customer.ReserveTable();
                        break;
                    }
                    case 6:
                    {
                        // customer.DisplayNotifs();
                        customer.SeeNotifs();
                        break;
                    }
                    case 7:
                    {
                        customer.Logout();
                        running = false;
                        break;
                    }
                    default:
                    {
                        cout << "Invalid input.\n";
                        break;
                    }

				}
			} // while
            }  

//-------------------------------------------- EMPLOYEE ----------------------------------------------
            else if (currentUser->GetUserType() == 2)
            {
        while (running) 
        { 
                cout << "\n\n--------------------------\n";
                cout << "        (EMPLOYEE MENU)" << endl;
                cout << "--------------------------\n";
                cout << "1. View Menu" << endl;
                cout << "2. Process Order" << endl;
                cout << "3. View Scheduled Orders" << endl;
                cout << "4. View Data Statistics" << endl;
                cout << "5. Manage Table Reservations" << endl;
                cout << "6. Logout" << endl;

                int ec; // ec = empChoice
                cout << "Enter your choice: ";
                cin >> ec;


                switch(ec)
                {
                    case 1:
                    { 
                        employee.ViewMenu(menuItems, 10);
                        break;
                    }
                    case 2:
                    {   employee.ProcessUserOrder(order, menuItems, 10);
						break;
                    }
                    case 3:
                    {   
                        employee.ViewSchedOrders();
                        break;
                    }
                    case 4:
                    {   employee.Statistics(menuItems);
                        break;
                    }
                    case 5:
                    {   employee.ReserveTable();
                        break;
                    }
                    case 6:
                    {
                        employee.Logout();
                        running = false;
                        break;
                    }
                    default:
                    {
                        cout << "Invalid input.\n";
                        break;
                    }




                }   // switch

            }   // while
            }


//-------------------------------------------- ADMINISTRATOR ----------------------------------------------
            else if (currentUser->GetUserType() == 3)
            {
         while (running) 
        { 
                cout << "\n\n--------------------------\n";
                cout << "    (ADMINISTRATOR MENU)" << endl;
                cout << "--------------------------\n";
                cout << " 1. View Stock" << endl;
                cout << " 2. View Scheduled Orders" << endl;
                cout << " 3. Process Order" << endl;
                cout << " 4. Display Notifications" << endl;
                cout << " 5. See and Respond to Complaints" << endl;
                cout << " 6. View Order History" << endl;
                cout << " 7. Add/Remove Menu Item"  << endl;
                cout << " 8. Manage Stock" << endl;
                cout << " 9. Remove User Credentials" << endl;
                cout << " 10. Logout" << endl;
 
            int ac;  // ac = admin choice
            cin >> ac;

            switch(ac)
            {
                case 1:
                {
                    admin.ViewStock(menuItems, 10);
                    break;
                }
                case 2:
                {
                    admin.ViewSchedOrders();
                    break;
                }
                case 3:
                {
                    admin.ProcessUserOrder(order, menuItems, 10);
                    break;
                } 
                case 4:
                {
                    admin.DisplayNotifs();
                    break;
                } 
                case 5:
                {
                    admin.RespondComp();
                    break;
                }
                case 6:
                {
               	    customer.ViewOrderHistory();
                    break;
                }
                case 7:
                {
                    admin.ManageItem(menuItems, 10);
                    break;
                }
                case 8:
                {
                    admin.ManageStock(menuItems, order, 10);
                    break;
                }
                case 9:
                {
                    int c;
                    cout << "Enter 1 to remove customer credentials" << endl;
                    cout << "Enter 2 to remove employee credentials" << endl;
                    cin >> c;
					if (c == 1)
						{
                            admin.RemoveCred("customer.txt");
                        }
					else if (c==2)
						{
                            admin.RemoveCred("employee.txt");
                        }
                    else 
                    {
                        cout << "Invalid input\n";
                    }

                    break;
                }
                case 10:
                {
                    cout << "Logging out admin...\n";
                    running = false;
                    break;
                }
                
                

            }  // switch
        }
	  

    }

    }

	    return 0;


}

