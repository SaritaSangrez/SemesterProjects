#include "notifications.h"
#include <string>

Notifications::Notifications()
{
    notifs = "";
}

Notifications::Notifications(string n)
{
    notifs = n;
}

void Notifications::SetNotif(const string &n)
{
    notifs = n;
}

string Notifications::GetNotif() const
{
    return notifs;
}



