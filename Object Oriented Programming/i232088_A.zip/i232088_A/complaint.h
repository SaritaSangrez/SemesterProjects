#ifndef COMPLAINT_H
#define COMPLAINT_H
#include <string>

class Complaint
{
    private:
    string complaint;

    public:
    Complaint();
    Complaint(string c);
    string GetComplaint() const;
    void SetComplaint(string c);
};

#endif

