#include "user.h"
#include <cstring>
#include <fstream>
#include <cstdlib>

int User::num_users = 0;
User::User(const char* name, const char* pass, int type)
{
	UserName = NULL;
	Password = NULL;
	int size = 50;
	UserName = new char[size];
	Password = new char[size];
	strcpy(UserName, name);
	strcpy(Password, pass);
	UserType = type;
	num_users++;
}

// Setters
void User::SetUserName(char* name)
{
	UserName = name;
}

void User::SetPassword(char* pass)
{
	Password = pass;
}

void User::SetUserType(int type)
{
	UserType = type;
}

// Getter
char* User::GetUserName() const
{
	return UserName;
}

int User::GetUserType() const
{
	return UserType;
}

char* User::GetPassword() const
{
	return Password;
}

istream& operator>>(istream& i, User& u)
{
	cout << "Enter your Username: ";
	i >> u.UserName;
	cout << "Enter your Password: ";
	i >> u.Password;
	return i;
}

void User::Register()
{
	cout << "Registering into the login system...\n";
	cin >> *this;
}

void User::Login() {
//--------------------------------CUSTOMER----------------------------------------------
	if (GetUserType()==1)
	{
		cout << "\nLogging into the system...\n";
		string EnteredPass; 
		cout << "\nEnter password for user " << GetUserName() << ": ";
		cin >> EnteredPass;
			if (EnteredPass == GetPassword()) 
			{
				cout << "Login successful!" << endl;
			}
			else 
			{
				cout << "Incorrect password. Login failed." << endl;
				Logout();
			}
			{
				ofstream write("users.txt", ios::app); // saving the user information in users.txt
				if (write.is_open())
				{
					write << "Name: " << GetUserName() << " " << "Password: " << GetPassword() << "\n";
					write.close();
				}
				else
				{
					cout << "Unable to open file\n";
					
				
				}
			}
			{
				ofstream write("customer.txt", ios::app); // saving the user information in customer.txt
				if (write.is_open())
				{
					write << "Name: " << GetUserName() << " " << "Password: " << GetPassword() << "\n";
					write.close();
				}
				else
				{
					cout << "Unable to open file\n";
				
				}
			}
	}

//---------------------------------------EMPLOYEE-----------------------------------------
	else if (GetUserType()==2)
	{
		cout << "\nLogging into the system...\n";
		string EnteredPass; 
		cout << "\nEnter password for user " << GetUserName() << ": ";
		cin >> EnteredPass;
			if (EnteredPass == GetPassword()) 
			{
				cout << "Login successful!" << endl;
			}
			else 
			{
				cout << "Incorrect password. Login failed." << endl;
				Logout();
			}
			
			{
				ofstream write("users.txt", ios::app); // saving the user information in users.txt
				
				if (write.is_open())
				{
					write << "Name: " << GetUserName() << " " << "Password: " << GetPassword() << "\n";
					write.close();
				}
				else
				{
					cout << "Unable to open file\n";
				
				}
			}
			{
				ofstream write("employee.txt", ios::app); // saving the user information in employee.txt
				if (write.is_open())
				{
					write << "Name: " << GetUserName() << " " << "Password: " << GetPassword() << "\n";
					write.close();
				}
				else
				{
					cout << "Unable to open file\n";
				
				}
			}
	}

//-----------------------------------------ADMIN------------------------------------------------
	else if (GetUserType()==3)
	{
		cout << "\nLogging into the system...\n";
		string EnteredPass; 
		cout << "\nEnter password for user " << GetUserName() << ": ";
		cin >> EnteredPass;
		ifstream read("admin.txt"); // reading the user information from admin.txt
		string storedName, storedPass;
		bool found = false;
		if (read.is_open())
		{
			while (read >> storedName >> storedPass)
			{
				if (storedName == GetUserName() && storedPass == EnteredPass)
				{
					cout << "Login successful!" << endl;
					found = true;
					break;
				}
			}
			read.close();
		}
		else
		{
			cout << "Unable to open file\n";
		}
		if (!found)
		{
			cout << "Incorrect username or password. Login failed." << endl;
			Logout();
			
		}	
	}
	else 
	{
		cout << "Unable to open file\n";
	}
	
}

void User::Logout()
{
	cout << "Logging out user " << GetUserName() << endl;
	exit(0);
}