#include <iostream>
#include <fstream>
#include <cstring>
#include "stock.h"
using namespace std;

// Initialize static variables
int Stock::num_items = 0;
int Stock::totalQuantity = 0;
double Stock::totalPrice = 0.0;

Stock::Stock() 
{
    // cout << "Parameterless constr of stock\n";
    item = new char[0];
    double price = 0;
    quantity = 0;
    itemID = 0;

    num_items++;
}


Stock::Stock(char *name, double p, int q, int i ) 
{
    // cout << "Parameterized constr of stock\n";
    int size = strlen(name) + 1;
     item = new char[size];
        // copy
       strcpy(item, name);

        price = p;
        itemID = i;
        quantity = q;

        num_items++;
        totalQuantity += q;
        totalPrice += p;
}

// Setters
void Stock:: SetItemID(int ID)
{
    itemID = ID;
}

void Stock:: SetItemName(char* name)
{
    item = name;
}

void Stock:: SetQuantity(int q)
{
    quantity = q;
}

void Stock:: SetItemPrice(double p)
{
    price = p;
}

// getters
char* Stock:: GetItemName() const
{
    return item;
}

int Stock::GetQuantity() const
{
    return quantity;
}

int Stock::GetItemID() const
{
    return itemID;
}

double Stock:: GetItemPrice() const
{
    return price;
}



void Stock::UpdateStock(int newQuantity)
{
    // Update totalQuantity
    totalQuantity = totalQuantity - quantity + newQuantity;


    if (newQuantity > 0)
    {
        quantity = newQuantity;
        cout <<"Items restocked successfully!\n";
        
    }
    else if (newQuantity >= 1000) {
        cout << "The stock should not exceed 1000.Please try again.\n";
    }

    else
    {
        cout << "Invalid stock quantity.\n";
    }
    
}

void Stock::Statistics()
{
    // Calculate the sum of quantities and prices
    int sumQuantity = totalQuantity;
    double sumPrice = totalPrice;

    // Calculate the average of quantity and price
    double avgQuantity = static_cast<double>(sumQuantity) / num_items;
    double avgPrice = sumPrice / num_items;

    // Display the statistics
    cout << "Total number of items: " << num_items << "\n";
    cout << "Sum of quantities: " << sumQuantity << "\n";
    cout << "Sum of prices: " << sumPrice << "\n";
    cout << "Average quantity: " << avgQuantity << "\n";
    cout << "Average price: " << avgPrice << "\n";
    
}

Stock::~Stock()
{
   // cout << "In destructor of Stock\n";
    
    delete [] item;
}

/*
void Stock::UpdateQuantity(int orderedQ)
{

}*/
