#ifndef ADMIN_H
#define ADMIN_H

#include "user.h"
#include "stock.h"
#include "complaint.h"
#include "notifications.h"

class Admin : public User
{
    Stock *menuItems;
    int menuSize;
    Notifications* notifs;        // Admin composes Notifications class
    const Complaint &complaint;    // Aggregation of complaint class
    static int SalesOfDay;

    public:
    Admin();
    Admin(char* name, char* pass, int type, Complaint & c, string notifs);
    void ViewMenu(const Stock* menuItems, int menuSize);
    void ViewStock(const Stock* menuItems, int menuSize);
    void DisplayNotifs();
    void ViewSchedOrders();
    void ProcessUserOrder(Order& order, Stock* menuItems, int menuSize);
    void ManageItem(Stock* menuItems, int menuSize);
    void RemoveCred(const char* filename);
    void RespondComp();
    void ManageStock(Stock *menuItems, Order &order, int menuSize);
    static void ShowSales()
    {
        cout << SalesOfDay << endl;
    }
};

#endif


