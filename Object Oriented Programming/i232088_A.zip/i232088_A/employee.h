#ifndef EMPLOYEE_H
#define EMPLOYEE_H

#include "user.h"
#include "stock.h"
#include "order.h"

class Employee : public User
{
    private:
    Stock* menuItems;
    int menuSize;
    const Order& order;     // aggregation of order object 
    static int SalesOfDay;

    public:
    Employee();
    Employee(char *name, char *password, int userType, Order &order);
    ~Employee();
    void ViewMenu(const Stock* menuItems, int menuSize) const; // Shows the available items in the cafe's menu.
    void ProcessUserOrder(Order& order, Stock* menuItems, int menuSize);  // process order and payment
    void ViewSchedOrders() const; // Displays a record of past orders made by customer.
    void Logout(); // Ends the employee's current session and exits the system.
    void ReserveTable(); // employee is able to reserve the table for customer
    void Statistics(Stock* s);   // Lets employee see sum of quantity, avg, sales of day etc;
    void UpdateQuantity();
    static void ShowSales()
    {
        cout << SalesOfDay << endl;
    }

};


#endif

