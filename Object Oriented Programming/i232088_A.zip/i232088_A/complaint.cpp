#include "complaint.h"
#include <string>

    Complaint::Complaint()
    {
        complaint = " ";
    }

    Complaint::Complaint(string c)
    {
        complaint = c;
    }

    string Complaint::GetComplaint() const
    {
        return complaint;
    }

    void Complaint::SetComplaint(string c)
    {
        complaint = c;
    }