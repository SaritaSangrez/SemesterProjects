#include "order.h"
//#include "stock.h"
#include "stock.cpp"
#include <iostream>
using namespace std;


Order::Order()
{
    ItemsOrdered = nullptr;
    QuantityOrdered = 0;
    TotalPrice = 0;
    OrderID = 0;
    TableReservation = false;
}

Order::Order(int q, int totalp, int ID, bool r) : ItemsOrdered(nullptr)
{
    QuantityOrdered = q;
    TotalPrice = totalp;
    OrderID = ID;
    TableReservation = r;
}

// Getters
int Order::GetOrderID() const 
{
    return OrderID;
}

const Stock* Order::GetItemsOrdered() const 
{
    return ItemsOrdered;
}

double Order::GetTotalPrice() const 
{
    return TotalPrice;
}

int Order::GetQuantityOrdered() const 
{
    return QuantityOrdered;
}


bool Order::GetTableReservation() const
{
    return TableReservation;
}

// Setters
void Order::SetOrderID(int id) 
{
    OrderID = id;
}

void Order::SetQuantityOrdered(int q)
{
    QuantityOrdered = q;
}

void Order::SetItemsOrdered(Stock* items) 
{
    ItemsOrdered = items;
}

void Order::SetTotalPrice(double totalPrice) 
{
    TotalPrice = totalPrice*QuantityOrdered;
}

void Order::SetTableReservation(bool reservation)
{
    TableReservation = reservation;
}


double Order::CalculateTotal() 
{
    if (ItemsOrdered != nullptr) 
    {

        for (int i = 0; i < GetQuantityOrdered(); ++i) 
        {
            TotalPrice += ItemsOrdered[i].GetItemPrice();
        }
        return TotalPrice;
    }
    else 
    {
        cout << "Order is empty. Total price is 0." << endl;
        return 0.0;
    }
}

void Order::ProcessOrder() 
{
    cout << "Processing payment for order ID: ";
    cin >> OrderID;

    ofstream out("customer.txt", ios::app); // saving the data in place_order.txt
    if (out.is_open())
    {
        out << "Order ID: " << OrderID << ", Amount: " << GetTotalPrice();
    }

    else
    {
        cout << "Unable to open file\n";
    }

    char c;
    cout << "Do you want to confirm payment? (Y/N): ";
    cin >> c;

    if (c == 'y' || c == 'Y') 
    {
        cout << "Items ordered: " << ItemsOrdered->GetItemName() << endl;
        cout << "Quantity ordered: " << GetQuantityOrdered() << endl;
        cout << "Total Payment: " << GetTotalPrice();
        cout << "Payment successful! Thank you for your purchase! :)" << endl;
    }
    else 
    {
        cout << "Payment cancelled. Please try again.\n" << endl;
    }
}

Order::~Order()
{
    delete [] ItemsOrdered;
}
