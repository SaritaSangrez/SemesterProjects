#ifndef CUSTOMER_H
#define CUSTOMER_H

#include "user.h"
#include "order.h"
#include "stock.h"
#include "complaint.h"
#include "notifications.h"
#include <string>

class Customer : public User    // class of Customer [INHERITED] from user class
{
    private:
    Order *orderHistory;
    int orderHistorySize;
    Complaint* complaint;     // composing object of complaint in customer class(student makes a complaint)
    const Notifications &notifs;   // aggregating object of notifcation in customer class

    public:
    Customer(); // default constructor
    Customer(char *name, char *password, int userType, string comp ,  const Notifications &n); // parameterized constructor
    ~Customer(); // destructors
    void ViewMenu(const Stock* menuItems, int menuSize) const; // Shows the available items in the cafe's menu.
    void PlaceOrder(Order& order, const Stock* menuItems, int menuSize); // Lets users select items and confirm their order
    void ViewOrderHistory() const; // Displays a record of past orders made by the user.
    void Logout(); // Ends the user's current session and exits the system.
    void ReserveTable(); // user is able to reserve the table
    void Makecomplaint();
    // void DisplayNotifs();    // shift to Admin class when u make
    void SeeNotifs();
};

#endif