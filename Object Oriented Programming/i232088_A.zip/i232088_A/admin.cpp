#include "user.h"
#include "stock.h"
#include "complaint.h"
#include "notifications.h"
#include "admin.h"
#include <fstream>
#include <string>

int Admin::SalesOfDay = 0;

Admin::Admin(): User("","",0), complaint(complaint)
{
    UserName = new char[0];
    Password = new char[0];
    notifs = new Notifications("");

}

Admin::Admin(char* name, char* pass, int type, Complaint & c, string n): User(name, pass, type), complaint(c)
{
    notifs = new Notifications("");
}

void Admin::DisplayNotifs()
{
    ofstream out("notifications.bin", ios::binary | ios::app);
    if(out.is_open()) {
        Notifications tempNotif;
        string notif;
        cout << "Enter the notification message: ";
        cin.ignore();
        getline(cin, notif);  // Get user input
        tempNotif.SetNotif(notif);

        // Write the size of the string to the file
        size_t size = notif.size();
        out.write(reinterpret_cast<char*>(&size), sizeof(size));

        // Write the string data to the file
        out.write(notif.c_str(), size);     // .c_str() returns pointer to array

        out.close();
        cout << "Notification has been recorded successfully.\n";
    } 
    else 
    {
        cout << "Unable to open file.\n";
    }
}

void Admin::ViewMenu(const Stock* menuItems, int menuSize)
{
        cout << "Viewing Menu: \n";
        // items that are in the menu will be shown to the user

        cout << "__________________________________________________\n";
        cout << "|         Items          |          Price        |\n";
        cout << "--------------------------------------------------\n";
    for (int i = 0; i < menuSize; ++i) 
    {
            cout << "      ID  " << menuItems[i].GetItemID() << ": " << menuItems[i].GetItemName() << "---------Price: " << menuItems[i].GetItemPrice() << "\n";
    }
                cout << "________________________________________________\n";
}

void Admin::ViewStock(const Stock* menuItems, int menuSize)
{
        cout << "Viewing Stock: \n";
        // items that are in the menu will be shown to the user

        cout << "__________________________________________________\n";
        cout << "|         Items          |          Price        |\n";
        cout << "--------------------------------------------------\n";
    for (int i = 0; i < menuSize; ++i) 
    {
            if (menuItems[i].GetQuantity() == 0) {
                cout << "\033[33m"; // ANSI escape code for yellow color
            } else if (menuItems[i].GetQuantity() < 15) {
                cout << "\033[31m"; // ANSI escape code for red color
            }
            cout << "      ID  " << menuItems[i].GetItemID() << ": " << menuItems[i].GetItemName() << "---------Quantity: " << menuItems[i].GetQuantity() << "\n";
            cout << "\033[0m"; // ANSI escape code to reset color
    }
                cout << "________________________________________________\n";
}

void Admin::ProcessUserOrder(Order& order, Stock* menuItems, int menuSize)
{
           cout << "Processing Order... \n";

    // Displaying menu
    ViewMenu(menuItems, menuSize);
    
    int ID;  // itemId
    int q; // quantity of the item
    char c;      // choice

    cout << "\nEnter the ID of the item to order: ";
    cin >> ID;

    cout << "Enter the quantity of item: ";
    cin >> q;

    order.SetQuantityOrdered(q);


    // Finding the item in the menu
    const Stock* item = nullptr; // selectedItem
    for (int i = 0; i < menuSize; ++i)
    {
        if (menuItems[i].GetItemID() == ID)
        {
        item = &menuItems[i];
            break;
        }
    }

    // if ordered quantity exceeds the quantity available
    if (q > item->GetQuantity()) {
        cout << "Insufficient stock available. Only " << item->GetQuantity() << " items in stock available.\n";
        return; // exit 
    }

    order.SetTotalPrice(static_cast<double>(item->GetItemPrice()));

        cout << "Do you want to confirm order? (Y/N): ";
        cin >> c;

        if (c == 'y' || c == 'Y') 
        {
            cout << "Item ordered: " << item->GetItemName() << endl;
            cout << "Quantity ordered: " << order.GetQuantityOrdered() << endl;
            cout << "Total Payment: " << order.GetTotalPrice() << endl;
            cout << "Order has been placed! Thank you for your purchase! :)" << endl;
            SalesOfDay+=1;

                        for (int i = 0; i < menuSize; ++i)
            {
                if (menuItems[i].GetItemID() == ID)
                {
                    menuItems[i].SetQuantity(menuItems[i].GetQuantity() - q);
                    cout << endl << endl << menuItems[i].GetQuantity() << endl << endl;
                    break;
                }
            }
        }
        else 
        {
            cout << "Payment cancelled. Please try again.\n" << endl;
        }

    
    ofstream write("stock.txt", ios::out | ios::trunc); // saving the data in stock.txt
    if (write.is_open())
    {     
        for (int i = 0; i < menuSize; ++i)
        {
            write << "ID: " << menuItems[i].GetItemID() << ", Name: " << menuItems[i].GetItemName() <<", Price: " << menuItems[i].GetItemPrice() << ", Quantity: " << menuItems[i].GetQuantity() << "\n";
        }
        write.close();
    }
}

void Admin::ViewSchedOrders()
{
        cout << "\nViewing scheduled orders:\n";

    ifstream read("place_order.txt"); // reading the data from place_order.txt
    if (read.is_open())
    {
        string s;
        while (getline(read, s))
        {
            cout << s << endl;
        }
        read.close();
    }
    else
    {
        cout << "No scheduled orders.\n";
    }
}

 void Admin::RespondComp()
{
        ifstream in("complaints.txt");
        ofstream out("respondcomplaints.txt", ios::app);  // Open the file to append responses

        if (!in.is_open() || !out.is_open()) {
            cout << "Error opening one or more files.\n";
            return;
        }

        string line, response;
        while (getline(in, line)) {  // Read each complaint
            cout << "Complaint: " << line << endl;
            cout << "Enter your response: ";
            cin.ignore();
            getline(cin, response);  // Get response from admin

            out << "Complaint: " << line << "\nResponse: " << response << "\n\n";  // Write the complaint and response
        }

        in.close();
        out.close();
        cout << "Responses recorded successfully.\n";
    }

    void Admin::ManageStock(Stock *menuItems, Order &order, int menuSize)
    {
       ViewStock( menuItems, menuSize);
        // Ask user which item they want to increase quantity of
        int choice;
        cout << "Enter the ID number of the item you want to increase quantity of: ";
        cin >> choice;

        if (choice < 1 || choice > menuSize) {
            cout << "Invalid choice. Please enter a valid item number." << endl;
            return;
        }

        int increaseAmount;
        cout << "Enter the quantity to order: ";
        cin >> increaseAmount;

        // Update quantity in memory
        menuItems[choice - 1].SetQuantity(menuItems->GetQuantity() + increaseAmount);

        // Update quantity in stock.txt
        ofstream write("stock.txt", ios::out | ios::trunc); // saving the data in stock.txt
        if (write.is_open())
        {     
            for (int i = 0; i < menuSize; ++i)
            {
                write << "ID: " << menuItems[i].GetItemID() << ", Name: " << menuItems[i].GetItemName() <<", Price: " << menuItems[i].GetItemPrice() << ", Quantity: " << menuItems[i].GetQuantity() << "\n";
            }
            write.close();
            cout << "Quantity increased successfully!\n";
        }

    }
    
 	void Admin:: RemoveCred(const char* filename) {
                string username, password;
        cout << "Enter the username to delete: ";
        cin >> username;
        cout << "Enter the password to delete: ";
        cin >> password;

        string lineToDelete = "Name: " + username + " Password: " + password;

        ifstream inFile(filename); 
        if (!inFile) {
            cout << "Error! Unable to open credentials file." << endl;
            return;
        }

        ofstream outFile("temp.txt");
        if (!outFile) {
            cout << "Error! Unable to create temporary file." << endl;
            inFile.close();
            return;
        }

        string line;
        bool found = false;

        while (getline(inFile, line)) {
            // Check if the line contains the username and password
            if (line.find(lineToDelete) == string::npos) {
                // If username and password pair not found in the line, write it to temporary file
                outFile << line << endl;
            } else {
                found = true;
            }
        }

        inFile.close();
        outFile.close();

        // Remove the original file
        remove(filename);

        // Rename the temporary file to original file
        rename("temp.txt", filename);

        if (found) {
            cout << "Credentials for user '" << username << "' with password '" << password << "' removed successfully." << endl;
        } else {
            cout << "Credentials not found for the provided username and password." << endl;
        }
    }



      void AddItem(Stock* menuItems, int& menuSize, char* itemName, double price, int quantity, int ID) {
        menuItems[menuSize] = Stock(itemName, price, quantity, ID);
        menuSize++;


        // Update stock.txt
        ofstream write("stock.txt", ios::app); // saving the data in stock.txt
        if (write.is_open())
        {     
            for (int i = 0; i < menuSize; ++i)
            {
               // cout << menuItems[i].GetItemName() << endl;
                write << "ID: " << menuItems[i].GetItemID() << ", Name: " << menuItems[i].GetItemName() <<", Price: " << menuItems[i].GetItemPrice() << ", Quantity: " << menuItems[i].GetQuantity() << "\n";
            }
            
            cout << "Item added successfully." << endl;
        }
        write.close();

    }
    

void Admin:: ManageItem(Stock* menuItems, int menuSize)
{
    ViewStock(menuItems, menuSize);
    bool found = false;
    char item[100]; // Assuming maximum item name length is 100 characters
    cout << "Enter the item you want to remove: ";
    cin >> item;

    // Find the item in the menuItems array
    for (int i = 0; i < menuSize; ++i) {
        if (strcmp(menuItems[i].GetItemName(), item) == 0) {
            found = true;
            // Remove the item from the array by shifting elements
            for (int j = i; j < menuSize - 1; ++j) {
                menuItems[j] = menuItems[j + 1];
            }
            menuSize--;
            break; // Exit the loop, the item is found and removed
        }
    }

    if (!found) {
        cout << "Item not found in stock." << endl;
        return;
    }

    // Update stock.txt
    ofstream outFile("stock.txt", ios::out);
    if (!outFile) {
        cout << "Error! Unable to open stock.txt" << endl;
        return;
    }

    ofstream write("stock.txt", ios::out | ios::trunc); // saving the data in stock.txt
    if (write.is_open())
    {     
        for (int i = 0; i < menuSize; ++i)
        {
            write << "ID: " << menuItems[i].GetItemID() << ", Name: " << menuItems[i].GetItemName() <<", Price: " << menuItems[i].GetItemPrice() << ", Quantity: " << menuItems[i].GetQuantity() << "\n";
        }
    }
    outFile.close();

    cout << "Item removed from stock successfully." << endl;
    char c;
    cout << "Do you want to add an item?(Y\\N) ";
    cin >> c;
    if (c=='y' || c=='Y')
    {
        char* newItemName = new char[100];
        int newItemID;
        double newItemPrice;
        int newItemQuantity;

        cout << "Enter the name of the item: ";
        cin >> newItemName;
        
        cout << "Enter the price of the item: ";
        cin >> newItemPrice;

        cout << "Enter the quantity of the item: ";
        cin >> newItemQuantity;

        cout << "Enter the item ID of item: ";
        cin >> newItemID;

        // AddItem() to add the new item to the menu
        AddItem(menuItems, menuSize, newItemName, newItemPrice, newItemQuantity, newItemID);

    }
    else if (c=='n' || c=='N')
    {
        cout << "No item added.";
    }
}

