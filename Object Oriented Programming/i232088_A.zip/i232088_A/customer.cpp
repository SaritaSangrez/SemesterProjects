#include "customer.h"
#include "stock.h"
#include "order.h"
#include "complaint.h"
#include "notifications.h"
#include <string>
#include <fstream>

Customer::Customer() : User("", "", 0), orderHistory(nullptr), notifs(notifs)
{
    UserName = new char[0];
    Password = new char[0];
    //UserType = 0;
    orderHistorySize = 0;
    complaint = new Complaint("");
    
}


Customer::Customer(char *name, char *pass, int type, string comp, const Notifications &n) : User(name, pass, type), orderHistory(nullptr), orderHistorySize(0), notifs(n) 
{
        complaint = new Complaint("");      // composing object of complaint (student makes a complaint)
}

void Customer::ViewMenu(const Stock* menuItems, int menuSize) const
{
    cout << "Viewing Menu: \n";
    // items that are in the menu will be shown to the user

        cout << "__________________________________________________\n";
        cout << "|         Items          |          Price        |\n";
        cout << "--------------------------------------------------\n";
    for (int i = 0; i < menuSize; ++i) 
    {
            cout << "      ID  " << menuItems[i].GetItemID() << ": " << menuItems[i].GetItemName() << "---------Price: " << menuItems[i].GetItemPrice() << "\n";
    }
                cout << "________________________________________________\n";	
    ofstream write("stock.txt", ios::app); // saving the data in stock.txt
    if (write.is_open())
    {     
        for (int i = 0; i < menuSize; ++i)
        {
            write << "ID: " << menuItems[i].GetItemID() << ", Name: " << menuItems[i].GetItemName() <<", Price: " << menuItems[i].GetItemPrice() << ", Quantity: " << menuItems[i].GetQuantity() << "\n";
        }
        write.close();
    }
}

void Customer:: PlaceOrder(Order &order, const Stock *menuItems, int menuSize)
{
    cout << "Placing Order... \n";

    // Displaying menu
    ViewMenu(menuItems, menuSize);
    
    int ID;  // itemId
    int q; // quantity of the item

    cout << "\nEnter the ID of the item to order: ";
    cin >> ID;

    cout << "Enter the quantity of item: ";
    cin >> q;

    order.SetQuantityOrdered(q);


    // Finding the item in the menu
    const Stock* item = nullptr; // selectedItem
    for (int i = 0; i < menuSize; ++i)
    {
        if (menuItems[i].GetItemID() == ID)
        {
        item = &menuItems[i];
            break;
        }
    }

    // if ordered quantity exceeds the quantity available
    if (q > item->GetQuantity()) {
        cout << "Insufficient stock available. Only " << item->GetQuantity() << " items in stock available.\n";
        return; // exit 
    }

    order.SetTotalPrice(static_cast<double>(item->GetItemPrice()));

 if (item != nullptr)
    {
        ofstream write("place_order.txt", ios::app); // saving the data in place_order.txt
        if (write.is_open())
        {
            write << "ID: " << item->GetItemID() << ", Name: " << item->GetItemName() << ", Price: RS." << item->GetItemPrice() << ", Quantity: " << q << "\n";
            write.close();
        }

         else
        {
            cout << "Unable to open file\n";
        }
    }
    else
    {
        cout << "Item with ID " << ID << " not found in the menu\n";
    }

            char c;

        cout << "Do you want to confirm payment? (Y/N): ";
        cin >> c;

        if (c == 'y' || c == 'Y') 
        {
            cout << "Item ordered: " << item->GetItemName() << endl;
            cout << "Quantity ordered: " << order.GetQuantityOrdered() << endl;
            cout << "Total Payment: " << order.GetTotalPrice() << endl;
            cout << "Payment successful! Thank you for your purchase! :)" << endl;
        }
        else 
        {
            cout << "Payment cancelled. Please try again.\n" << endl;
        }
    }


void Customer::ViewOrderHistory() const
{
    cout << "\nViewing order history :\n";

    ifstream read("place_order.txt"); // reading the data from place_order.txt
    if (read.is_open())
    {
        string s;
        while (getline(read, s))
        {
            cout << s << endl;
        }
        read.close();
    }
    else
    {
        cout << "No order history available\n";
    }
}

void Customer::Logout()
{
    cout << "You have Logged out.\n";

}

Customer::~Customer() // deallocating memory
{
    delete[] orderHistory;
    delete [] complaint;
}

void Customer::ReserveTable() 
{
    cout << "Enter the date and time for the reservation : ";
    string r;
    cin.ignore(); // Ignore the newline character
    getline(cin, r);

    cout << "\nTable reserved successfully.\n";
}

void Customer::Makecomplaint()
{
        string comp;
        cout << "Please enter your complaint: ";
        cin.ignore();  // Ignore leftover newline from previous input
        getline(cin, comp);

        Complaint tempComp;
        tempComp.SetComplaint(comp);

        ofstream out("complaints.txt", ios::app);  // Open the text file in append mode
        if (out.is_open()) {
            out << comp << endl;  // Write the complaint to the file followed by a newline

            out.close();
            cout << "Your complaint has been recorded successfully!\n";
        } else {
            cout << "Unable to open file.\n";
        }
}


void Customer::SeeNotifs()
{

      Notifications tempNotif;
    ifstream in("notifications.bin", ios::binary);
    if (in.is_open())
    {
        // Read the size of the string from the file
        size_t size;
        while(in.read(reinterpret_cast<char*>(&size), sizeof(size)))
        {
            // Read the string data from the file
            char* buffer = new char[size + 1];
            in.read(buffer, size);
            buffer[size] = '\0';  // Null-terminate the string

            // Set the notification message and display it
            tempNotif.SetNotif(buffer);
            cout << "Notification: " << tempNotif.GetNotif() << endl;

            delete[] buffer;
        }

        in.close();
    }
    else 
    {
        cout << "Unable to open file.\n";
    }
}

// For admin class but here just to check
/*void Customer::DisplayNotifs()
{

     ofstream out("notifications.bin", ios::binary | ios::app);
    if(out.is_open()) {
        Notifications tempNotif;
        string notif;
        cout << "Enter the notification message: ";
        cin.ignore();
        getline(cin, notif);  // Get user input
        tempNotif.SetNotif(notif);

        // Write the size of the string to the file
        size_t size = notif.size();
        out.write(reinterpret_cast<char*>(&size), sizeof(size));

        // Write the string data to the file
        out.write(notif.c_str(), size);     // .c_str() returns pointer to array

        out.close();
        cout << "Notification has been recorded successfully.\n";
    } 
    else 
    {
        cout << "Unable to open file.\n";
    }
}*/



