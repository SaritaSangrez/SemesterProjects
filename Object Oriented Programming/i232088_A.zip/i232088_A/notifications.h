#ifndef NOTIFICATIONS_H
#define NOTIFICATIONS_H

class Notifications
{
    private:
    string notifs;

    public:
    Notifications();
    Notifications(string n);
    string GetNotif() const;
    void SetNotif(const string &n);
};

#endif